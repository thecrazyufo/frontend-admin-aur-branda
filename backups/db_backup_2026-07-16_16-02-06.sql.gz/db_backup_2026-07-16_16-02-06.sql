--
-- PostgreSQL database dump
--

\restrict xieJMOIRNRGS9mCTxWQDwXetnuhmu0VCBb3hLz2uHYPYjXJ9G5d2bNzFxqFaIA2

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.activations (
    id character varying(255) NOT NULL,
    license_id integer,
    machine_id character varying(255),
    status character varying(50),
    activated_at timestamp without time zone
);


ALTER TABLE public.activations OWNER TO admin;

--
-- Name: admin_users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.admin_users (
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role character varying(255) NOT NULL,
    brand_id character varying(255) NOT NULL,
    full_name character varying(255),
    email character varying(255)
);


ALTER TABLE public.admin_users OWNER TO admin;

--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.blog_posts (
    id character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    excerpt text,
    content text NOT NULL,
    category character varying(255),
    tags jsonb,
    published_at character varying(255),
    read_time integer,
    cover_image character varying(255),
    author jsonb,
    seo jsonb,
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL,
    product_ids jsonb
);


ALTER TABLE public.blog_posts OWNER TO admin;

--
-- Name: brand_configs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.brand_configs (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    domain character varying(255) NOT NULL,
    admin_domain character varying(255),
    theme_colors text,
    features text,
    is_active boolean DEFAULT true NOT NULL,
    dev_port character varying(255),
    layout_template character varying(255),
    logo_url character varying(255)
);


ALTER TABLE public.brand_configs OWNER TO admin;

--
-- Name: career_positions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.career_positions (
    id character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    location character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    description text NOT NULL,
    requirements text,
    status character varying(255) NOT NULL,
    meta_title character varying(255),
    meta_description text,
    meta_keywords character varying(255),
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL
);


ALTER TABLE public.career_positions OWNER TO admin;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.categories (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    icon character varying(255),
    count integer,
    color character varying(255),
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL,
    product_ids jsonb
);


ALTER TABLE public.categories OWNER TO admin;

--
-- Name: client_logos; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.client_logos (
    id character varying(255) NOT NULL,
    site_id character varying(255) NOT NULL,
    company_name character varying(255) NOT NULL,
    logo_url character varying(1024) NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    description text,
    case_study text,
    product_ids jsonb
);


ALTER TABLE public.client_logos OWNER TO admin;

--
-- Name: coupons; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.coupons (
    id character varying(255) NOT NULL,
    code character varying(255) NOT NULL,
    discount_percentage integer NOT NULL,
    active boolean DEFAULT true NOT NULL,
    expires_at timestamp without time zone,
    site_id character varying(255) NOT NULL
);


ALTER TABLE public.coupons OWNER TO admin;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO admin;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO admin;

--
-- Name: faqs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.faqs (
    id character varying(255) NOT NULL,
    question character varying(255) NOT NULL,
    answer text NOT NULL,
    category character varying(255) NOT NULL,
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL,
    product_id character varying(255),
    product_ids jsonb
);


ALTER TABLE public.faqs OWNER TO admin;

--
-- Name: format_compatibility; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.format_compatibility (
    id character varying(255) NOT NULL,
    source_format character varying(100) NOT NULL,
    target_format character varying(100) NOT NULL,
    compatibility_score integer DEFAULT 50 NOT NULL,
    match_type character varying(20) DEFAULT 'COMPATIBLE'::character varying NOT NULL,
    notes text
);


ALTER TABLE public.format_compatibility OWNER TO admin;

--
-- Name: help_articles; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.help_articles (
    id character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    excerpt text,
    content text NOT NULL,
    category character varying(255) NOT NULL,
    tags jsonb,
    published_at character varying(255),
    helpful integer,
    not_helpful integer,
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL,
    product_id character varying(255),
    product_ids jsonb
);


ALTER TABLE public.help_articles OWNER TO admin;

--
-- Name: inquiries; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.inquiries (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    subject character varying(255) NOT NULL,
    message text NOT NULL,
    created_at timestamp without time zone,
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL
);


ALTER TABLE public.inquiries OWNER TO admin;

--
-- Name: inquiries_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.inquiries ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.inquiries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: key_features; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.key_features (
    id character varying(255) NOT NULL,
    feature_key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL
);


ALTER TABLE public.key_features OWNER TO admin;

--
-- Name: legacy_license_activations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.legacy_license_activations (
    id character varying(255) NOT NULL,
    license_key_id character varying(255),
    hardware_fingerprint character varying(255) NOT NULL,
    device_name character varying(255),
    activated_at timestamp without time zone,
    last_check_in timestamp without time zone
);


ALTER TABLE public.legacy_license_activations OWNER TO admin;

--
-- Name: license_activations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.license_activations (
    id integer NOT NULL,
    license_id integer NOT NULL,
    machine_id character varying(100) NOT NULL,
    machine_name character varying(100),
    os_name character varying(100),
    ip_address character varying(45),
    activated_at timestamp with time zone,
    last_checked_at timestamp with time zone
);


ALTER TABLE public.license_activations OWNER TO admin;

--
-- Name: license_activations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.license_activations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.license_activations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: license_keys; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.license_keys (
    id character varying(255) NOT NULL,
    activation_key character varying(255) NOT NULL,
    order_id character varying(255) NOT NULL,
    product_id character varying(255) NOT NULL,
    pricing_tier_name character varying(255) NOT NULL,
    customer_email character varying(255),
    status character varying(255) NOT NULL,
    max_devices integer DEFAULT 3 NOT NULL,
    created_at timestamp without time zone,
    expires_at timestamp without time zone,
    site_id character varying(255) DEFAULT 'brandA'::character varying NOT NULL,
    is_offline_capable boolean DEFAULT false NOT NULL
);


ALTER TABLE public.license_keys OWNER TO admin;

--
-- Name: licenses; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.licenses (
    id integer NOT NULL,
    license_key character varying(50) NOT NULL,
    status character varying(20) DEFAULT 'ACTIVE'::character varying NOT NULL,
    license_type character varying(30) DEFAULT 'STANDARD'::character varying NOT NULL,
    expires_at timestamp with time zone,
    max_activations integer DEFAULT 3,
    created_at timestamp with time zone,
    site_id character varying(255) DEFAULT 'brandA'::character varying NOT NULL
);


ALTER TABLE public.licenses OWNER TO admin;

--
-- Name: licenses_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.licenses ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.licenses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.orders (
    id character varying(255) NOT NULL,
    order_id character varying(255) NOT NULL,
    customer_email character varying(255) NOT NULL,
    product_id character varying(255) NOT NULL,
    product_name character varying(255) NOT NULL,
    pricing_tier_name character varying(255) NOT NULL,
    amount double precision,
    currency character varying(255),
    payment_status character varying(255),
    payment_method character varying(255),
    activation_key character varying(255),
    created_at timestamp without time zone,
    site_id character varying(255) NOT NULL,
    billing_name character varying(255),
    billing_company character varying(255),
    billing_address character varying(255),
    billing_city character varying(255),
    billing_state character varying(255),
    billing_zip character varying(255),
    billing_country character varying(255),
    tax_id character varying(255),
    tax_amount double precision DEFAULT 0 NOT NULL,
    tax_rate double precision DEFAULT 0 NOT NULL
);


ALTER TABLE public.orders OWNER TO admin;

--
-- Name: products; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.products (
    id character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    short_description text,
    description text,
    category character varying(255) NOT NULL,
    tags jsonb,
    rating double precision DEFAULT 0,
    review_count integer DEFAULT 0,
    downloads character varying(255),
    badge character varying(255),
    version character varying(255),
    last_updated character varying(255),
    trial_download_url character varying(255),
    features jsonb,
    platforms jsonb,
    supported_formats jsonb,
    screenshots jsonb,
    pricing jsonb,
    seo jsonb,
    system_requirements jsonb,
    how_it_works jsonb,
    reviews jsonb,
    faqs jsonb,
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    related_product_ids jsonb,
    license_comparison jsonb,
    source_formats jsonb,
    target_formats jsonb,
    capabilities jsonb DEFAULT '{}'::jsonb,
    installation_success_url character varying(255),
    uninstallation_success_url character varying(255),
    installer_url character varying(255)
);


ALTER TABLE public.products OWNER TO admin;

--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.site_settings (
    id character varying(255) NOT NULL,
    site_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    tagline character varying(255) NOT NULL,
    description text,
    url character varying(255),
    email character varying(255),
    phone character varying(255),
    address character varying(255),
    socials jsonb,
    stats jsonb,
    trust_badges jsonb,
    team_members jsonb,
    pricing_comparison jsonb,
    pricing_faqs jsonb,
    theme jsonb,
    main_navigation jsonb,
    footer_config jsonb,
    hero jsonb,
    home_sections jsonb,
    legal_pages jsonb,
    about_page jsonb,
    coupons jsonb,
    announcement jsonb,
    seo_defaults jsonb,
    careers_page jsonb,
    clients_page jsonb,
    review_platform_name character varying(100),
    review_platform_url character varying(500),
    review_platform_rating numeric(3,1),
    review_platform_count integer,
    live_chat_embed_code text,
    press_mentions jsonb
);


ALTER TABLE public.site_settings OWNER TO admin;

--
-- Name: source_formats; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.source_formats (
    id character varying(255) NOT NULL,
    format_key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    icon character varying(255),
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL,
    supports_multiple_accounts boolean DEFAULT false NOT NULL,
    category character varying(255)
);


ALTER TABLE public.source_formats OWNER TO admin;

--
-- Name: supported_clients; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.supported_clients (
    id character varying(255) NOT NULL,
    client_key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    icon character varying(255),
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL
);


ALTER TABLE public.supported_clients OWNER TO admin;

--
-- Name: target_formats; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.target_formats (
    id character varying(255) NOT NULL,
    format_key character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    icon character varying(255),
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL,
    supports_multiple_accounts boolean DEFAULT false NOT NULL,
    category character varying(255)
);


ALTER TABLE public.target_formats OWNER TO admin;

--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.testimonials (
    id character varying(255) NOT NULL,
    site_id character varying(255) NOT NULL,
    author_name character varying(255) NOT NULL,
    author_title character varying(255),
    company character varying(255),
    content text NOT NULL,
    rating integer DEFAULT 5 NOT NULL,
    avatar_url character varying(1024),
    is_featured boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    product_ids jsonb
);


ALTER TABLE public.testimonials OWNER TO admin;

--
-- Name: trial_downloads; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.trial_downloads (
    id bigint NOT NULL,
    email character varying(255) NOT NULL,
    product_slug character varying(255) NOT NULL,
    downloaded_at timestamp without time zone,
    site_id character varying(255) DEFAULT 'default'::character varying NOT NULL,
    product_id character varying(50)
);


ALTER TABLE public.trial_downloads OWNER TO admin;

--
-- Name: trial_downloads_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.trial_downloads ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.trial_downloads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: url_redirects; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.url_redirects (
    id bigint NOT NULL,
    source_path character varying(255) NOT NULL,
    target_path character varying(255) NOT NULL,
    redirect_type integer DEFAULT 301 NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    site_id character varying(255) NOT NULL
);


ALTER TABLE public.url_redirects OWNER TO admin;

--
-- Name: url_redirects_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

ALTER TABLE public.url_redirects ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.url_redirects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: activations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.activations (id, license_id, machine_id, status, activated_at) FROM stdin;
\.


--
-- Data for Name: admin_users; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.admin_users (username, password, role, brand_id, full_name, email) FROM stdin;
adminA	$2a$10$WvMRsusv5nfEKqvYobvmDOp9wKuI1mVaD.9hKo4GAi.6Nnu8sodeC	ADMIN	brandA	Prism Migration Administrator	admin@prismmigration.local
staffA	$2a$10$XwWaNyW46TbJuW1KE1Sy1uhn8aSfea1CsK9QgU/krGaS1isIWHXXe	SEO_CW_PRODUCT_MANAGER	brandA	Prism Migration SEO & Product Staff	staff@prismmigration.local
adminB	$2a$10$sWl1A4nqMTrteSrRdHOOBOuTwRAyp/lQ3ooOIZIFf1UZtgKmhvYrG	ADMIN	apexbyte	ApexByte Administrator	admin@apexbyte.local
staffB	$2a$10$ZE4j5JcutstAderO1iQFHec9qr3QOtgojSpoZruL1rt9YDAZ/hZDi	SEO_CW_PRODUCT_MANAGER	apexbyte	ApexByte SEO & Product Staff	staff@apexbyte.local
adminC	$2a$10$eM0IiaTz.lpyG37VfE4biuoAYxjbmf7m8U8O9MRdHvmmvIx26FvUq	ADMIN	migrationuncle	Migration Uncle Administrator	admin@migrationuncle.local
staffC	$2a$10$HiRe0vZBf7FC0rIKB3.AI.tvxh8j33ECUNJqSzqnjgcEV26t9RwqC	SEO_CW_PRODUCT_MANAGER	migrationuncle	Migration Uncle SEO & Product Staff	staff@migrationuncle.local
as	$2a$10$Ms48JFVIPD6PP4tKNKtd3.ilqxb1nMI3H30H.htL5Lu7CHCy7Hkki	SEO_CW_PRODUCT_MANAGER	brandA	vineet	brrrandyyy@gmail.com
aa	$2a$10$GZUV.tGU/bB36BGcozf.Aew8xRsxSIWyzLJHkAVbi4wBcjZoP/UYG	ADMIN	brandA	Akash Sahu	akashsahu786aim@gmail.com
ba	$2a$10$cI8YxwUrdDuFD1n64HcKDegoMz2P4VTXKjCQIavXBEA1vObhbIY/q	ADMIN	apexbyte	vineet	brrrandyyy@gmail.com
bs	$2a$10$dAboWxH.U2AyyvLDRwdiNuUIjwBio67RYHRqDbSO.sW6ryuQxqgCe	SEO_CW_PRODUCT_MANAGER	apexbyte	vineet	brrrandyyy@gmail.com
cs	$2a$10$5eg5iwIIc4DUqeMG4j8bN.DaVTy4YF9C694xpk3MchZ79bKrBdWfW	SEO_CW_PRODUCT_MANAGER	migrationuncle	Udit Sharma	clienthelp@arysonsupport.com
ca	$2a$10$IjcAlIS/fdInyCfwqN1Pe.SBvBozJwjeT9y7KDVMLI.lns0qxAOFe	ADMIN	migrationuncle	Udit Sharma	clienthelp@arysonsupport.com
owner	$2a$10$GtZf5bAAnUABIOHtG0Fw/.xclC5qrBovtRsEi7OsLo.u7zzeu2/YO	SUPER_ADMIN	all	Root Owner	owner@platform.local
aas	$2a$10$/GDe/b96hRHQFMAUk7fNi.a5robPNv532kpuZnl6docMXDmT5woMO	SEO_CW_PRODUCT_MANAGER	brandA	The Crazy UFO	thecrazyufo@gmail.com
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.blog_posts (id, slug, title, excerpt, content, category, tags, published_at, read_time, cover_image, author, seo, site_id, product_ids) FROM stdin;
\.


--
-- Data for Name: brand_configs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.brand_configs (id, name, domain, admin_domain, theme_colors, features, is_active, dev_port, layout_template, logo_url) FROM stdin;
brandD	Brand D	brandd.local	\N	{"primary":"#10b981","accent":"emerald"}	\N	t	3004	corporate	\N
brandE	Brand E	brande.local	\N	{"primary":"#f59e0b","accent":"amber"}	\N	t	3005	ecomm-dark	\N
brandA	Prism Migration	prismmigration.local	\N	{"primary":"#6366f1","accent":"indigo"}	\N	t	3001	luxury	\N
migrationuncle	Migration Uncle	migrationuncle.local	\N	{"primary":"#10B981","accent":"#F59E0B"}	\N	t	3003	\N	\N
apexbyte	ApexByte Soft	apexbyte.local	\N	{"primary":"#2563EB","accent":"#0EA5E9"}	\N	t	3002	\N	\N
\.


--
-- Data for Name: career_positions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.career_positions (id, title, location, type, description, requirements, status, meta_title, meta_description, meta_keywords, site_id) FROM stdin;
career-brandA-1	Senior Java Developer	Remote, US	Full-Time	We are seeking a senior-level Java engineer with 5+ years of experience in high-performance backends.	• 5+ years of experience with Java and Spring Boot\n• Strong knowledge of SQL databases and Liquibase\n• Excellent problem-solving skills	OPEN	Join Us as a Senior Java Developer	Apply now for the Senior Java Developer position at our enterprise solutions team.	java, developer, remote, spring boot	brandA
career-brandA-2	Technical Writer	Hybrid, New York	Part-Time	Looking for a technical writer to document system architectures and write user guide manuals.	• Experience in technical documentation or technical writing\n• Familiarity with Markdown and Markdown rendering engines\n• Basic understanding of enterprise software concepts	OPEN	We are hiring: Technical Writer	Help us write clear technical guide documentation.	writer, documentation, markdown	brandA
career-brandA-3	Product Manager (Migration Suite)	Remote, Global	Full-Time	Help define the roadmap for our next-generation data migration and integration platforms.	• 3+ years in product management for B2B developer tools\n• Deep understanding of ETL, cloud databases, or data migration\n• Strong communication skills	OPEN	Product Manager Job Opening	Lead the roadmap for our migration tools.	product manager, migration, B2B	brandA
se-backend-apex	Senior Backend Engineer (Java)	Remote (US/Canada)	Full-time	We are looking for an experienced Java Spring Boot engineer to help build the next generation of our data migration engine. You will be working on highly concurrent data streaming pipelines.	- 5+ years of Java experience\n- Strong understanding of Spring Boot\n- Experience with concurrent programming\n- Familiarity with PostgreSQL	OPEN	\N	\N	\N	apexbyte
tech-support-apex	Technical Support Specialist	London, UK / Remote	Full-time	Join our global support team to assist enterprise clients with complex database and email migrations. Excellent communication skills required.	- 2+ years in technical support\n- Knowledge of Microsoft Exchange and Office 365\n- Basic SQL knowledge\n- Excellent written English	OPEN	\N	\N	\N	apexbyte
product-manager-apex	Product Manager - Cloud Solutions	San Francisco, CA	Full-time	Lead the product strategy for our rapidly growing suite of cloud backup solutions.	- 3+ years in B2B SaaS Product Management\n- Experience in the data backup/security space\n- Strong analytical skills	OPEN	\N	\N	\N	apexbyte
career-brandD-1	Senior Java Developer	Remote, US	Full-Time	We are seeking a senior-level Java engineer with 5+ years of experience in high-performance backends.	• 5+ years of experience with Java and Spring Boot\n• Strong knowledge of SQL databases and Liquibase\n• Excellent problem-solving skills	OPEN	Join Us as a Senior Java Developer	Apply now for the Senior Java Developer position at our enterprise solutions team.	java, developer, remote, spring boot	brandD
career-brandD-2	Technical Writer	Hybrid, New York	Part-Time	Looking for a technical writer to document system architectures and write user guide manuals.	• Experience in technical documentation or technical writing\n• Familiarity with Markdown and Markdown rendering engines\n• Basic understanding of enterprise software concepts	OPEN	We are hiring: Technical Writer	Help us write clear technical guide documentation.	writer, documentation, markdown	brandD
career-brandD-3	Product Manager (Migration Suite)	Remote, Global	Full-Time	Help define the roadmap for our next-generation data migration and integration platforms.	• 3+ years in product management for B2B developer tools\n• Deep understanding of ETL, cloud databases, or data migration\n• Strong communication skills	OPEN	Product Manager Job Opening	Lead the roadmap for our migration tools.	product manager, migration, B2B	brandD
career-brandE-1	Senior Java Developer	Remote, US	Full-Time	We are seeking a senior-level Java engineer with 5+ years of experience in high-performance backends.	• 5+ years of experience with Java and Spring Boot\n• Strong knowledge of SQL databases and Liquibase\n• Excellent problem-solving skills	OPEN	Join Us as a Senior Java Developer	Apply now for the Senior Java Developer position at our enterprise solutions team.	java, developer, remote, spring boot	brandE
career-brandE-2	Technical Writer	Hybrid, New York	Part-Time	Looking for a technical writer to document system architectures and write user guide manuals.	• Experience in technical documentation or technical writing\n• Familiarity with Markdown and Markdown rendering engines\n• Basic understanding of enterprise software concepts	OPEN	We are hiring: Technical Writer	Help us write clear technical guide documentation.	writer, documentation, markdown	brandE
career-brandE-3	Product Manager (Migration Suite)	Remote, Global	Full-Time	Help define the roadmap for our next-generation data migration and integration platforms.	• 3+ years in product management for B2B developer tools\n• Deep understanding of ETL, cloud databases, or data migration\n• Strong communication skills	OPEN	Product Manager Job Opening	Lead the roadmap for our migration tools.	product manager, migration, B2B	brandE
support-mgu	Friendly Support Agent	Remote (US Only)	Full-time	We're looking for patient, kind, and tech-savvy individuals to help our customers with their migrations.	- Incredible patience and empathy\n- Good typing speed\n- Basic knowledge of Windows and Outlook	OPEN	\N	\N	\N	migrationuncle
dev-mgu-1	Software Engineer (.NET)	Austin, TX / Remote	Full-time	Help us build fast, reliable, and easy-to-use data parsing tools.	- 3+ years of C# / .NET experience\n- Experience with binary file parsing\n- Passion for clean code	OPEN	\N	\N	\N	migrationuncle
marketing-mgu-1	Content Writer	Remote	Part-time	Write friendly, non-jargon articles explaining complex tech topics to home users.	- Excellent English writing skills\n- Ability to simplify technical concepts\n- SEO knowledge is a plus	OPEN	\N	\N	\N	migrationuncle
qa-mgu-1	QA Tester	Remote	Contract	Break our software before our customers do!	- Keen eye for detail\n- Experience setting up virtual machines\n- Familiarity with different email clients	OPEN	\N	\N	\N	migrationuncle
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.categories (id, name, slug, description, icon, count, color, site_id, product_ids) FROM stdin;
cloud-migration	Cloud Migration	cloud-migration	Seamlessly move data between cloud platforms — O365, Google Workspace, AWS.	cloud	6	cyan	brandA	[]
mailbox-recovery	Mailbox Recovery	mailbox-recovery	Recover and repair corrupted or inaccessible PST, OST, and mailbox files.	hard-drive	7	orange	brandA	[]
data-export	Data Export/Import	data-export	Export emails and contacts to CSV, vCard, PDF, HTML, and more.	download	5	red	brandA	[]
apexbyte-migration	Migration Tools	apexbyte-migration	Enterprise-grade tools to migrate email servers and cloud mailboxes.	\N	\N	\N	apexbyte	["apexbyte-exchange-migrator", "apexbyte-duplicate-remover"]
apexbyte-backup	Backup Solutions	apexbyte-backup	Securely backup and archive your critical corporate data.	\N	\N	\N	apexbyte	["apexbyte-cloud-backup-pro", "apexbyte-gws-backup"]
apexbyte-converters	File Converters	apexbyte-converters	Fast and accurate binary file converters for documents and archives.	\N	\N	\N	apexbyte	["apexbyte-pdf-converter"]
apexbyte-database	Database Tools	apexbyte-database	Migrate between SQL Server, Oracle, MySQL, and PostgreSQL seamlessly.	\N	\N	\N	apexbyte	["apexbyte-sql-migrator"]
email-migration	Email Migration	email-migration	Migrate emails across platforms — Gmail, Outlook, Office 365, Yahoo, and more.	mail	12	blue	brandA	["PRM-MIG-2026-001", "PRM-MIG-2026-004"]
backup-tools	Backup Tools	backup-tools	Protect your email data with automated cloud and local backup solutions.	shield	8	green	brandA	["PRM-MIG-2026-003"]
file-converter	File Converters	file-converter	Convert between PST, MBOX, EML, MSG, PDF, and other email file formats.	refresh-cw	10	purple	brandA	["PRM-MIG-2026-002"]
brandD-cat	Security Backups	brandD-cat	Tools and utilities for security backups	cloud	1	blue	brandD	["brandD-p1"]
brandE-cat	File Converters	brandE-cat	Tools and utilities for file converters	cloud	1	blue	brandE	["brandE-p1"]
mgu-backup	Backup	backup	Securely backup your emails and data to prevent any loss.	\N	\N	\N	migrationuncle	["uncle-email-backup-pro"]
mgu-converter	Converter	converter	Convert your files into universal formats that you can read anywhere.	\N	\N	\N	migrationuncle	["uncle-mbox-to-pst", "uncle-ost-to-pst"]
mgu-migration	Migration	migration	Simple and reliable tools to move emails and data from one platform to another.	\N	\N	\N	migrationuncle	["uncle-pst-to-gmail", "uncle-cloud-migration-kit"]
mgu-utility	Utility	utility	Handy utilities to clean up and organize your digital life.	\N	\N	\N	migrationuncle	["uncle-ost-recovery", "uncle-duplicate-cleaner", "uncle-eml-viewer"]
\.


--
-- Data for Name: client_logos; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.client_logos (id, site_id, company_name, logo_url, display_order, created_at, updated_at, description, case_study, product_ids) FROM stdin;
mgu-client-1	migrationuncle	Bob's Plumbing	/logos/bobs-plumbing.svg	0	2026-07-10 16:57:49.725752	2026-07-10 16:57:49.725775	\N	\N	\N
mgu-client-2	migrationuncle	Main Street Bakery	/logos/main-st-bakery.svg	0	2026-07-10 16:57:49.726529	2026-07-10 16:57:49.726589	\N	\N	\N
mgu-client-3	migrationuncle	Greenfield Accounting	/logos/greenfield.svg	0	2026-07-10 16:57:49.727745	2026-07-10 16:57:49.727776	\N	\N	\N
mgu-client-4	migrationuncle	Local Tech Support Co.	/logos/local-tech.svg	0	2026-07-10 16:57:49.72841	2026-07-10 16:57:49.728419	\N	\N	\N
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.coupons (id, code, discount_percentage, active, expires_at, site_id) FROM stdin;
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
001-categories	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.842623	1	EXECUTED	9:de77b1c643061ee4070fa077d47ebf24	createTable tableName=categories		\N	4.29.2	\N	\N	3511280792
001-faqs	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.848986	2	EXECUTED	9:24bfc18d945c45cd5262297acd6a0b45	createTable tableName=faqs		\N	4.29.2	\N	\N	3511280792
001-help-articles	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.856014	3	EXECUTED	9:2791e8edf4567df6557ce925f8a4ac8a	createTable tableName=help_articles		\N	4.29.2	\N	\N	3511280792
001-inquiries	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.861344	4	EXECUTED	9:6eb21838086324895ed730ba67230397	createTable tableName=inquiries		\N	4.29.2	\N	\N	3511280792
001-license-keys	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.866838	5	EXECUTED	9:1415176fbdd89dee3b9f2eb144956bd0	createTable tableName=license_keys		\N	4.29.2	\N	\N	3511280792
001-legacy-license-activations	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.873629	6	EXECUTED	9:c88fa7436c96f45ef96894fb2b07a5e0	createTable tableName=legacy_license_activations; addForeignKeyConstraint baseTableName=legacy_license_activations, constraintName=fk_legacy_activation_license_key, referencedTableName=license_keys		\N	4.29.2	\N	\N	3511280792
001-licenses	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.87884	7	EXECUTED	9:99d4bd6e546430f4d93fc1cc72993942	createTable tableName=licenses		\N	4.29.2	\N	\N	3511280792
001-activations	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.884041	8	EXECUTED	9:0c8ec9de1c0970be8d7ec9a396d73d5e	createTable tableName=activations; addForeignKeyConstraint baseTableName=activations, constraintName=fk_activation_license, referencedTableName=licenses		\N	4.29.2	\N	\N	3511280792
001-products	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.889564	9	EXECUTED	9:34141993c9775f8b2c44c0715d7c515b	createTable tableName=products		\N	4.29.2	\N	\N	3511280792
001-blog-posts	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.895073	10	EXECUTED	9:ef28debacad12cd23761df551b72e3ee	createTable tableName=blog_posts		\N	4.29.2	\N	\N	3511280792
001-site-settings	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.900142	11	EXECUTED	9:4fb42f0ea7904b98bc434cc0942ac9c7	createTable tableName=site_settings		\N	4.29.2	\N	\N	3511280792
001-trial-downloads	platform	db/changelog/001-initial-schema.xml	2026-07-08 11:48:00.904529	12	EXECUTED	9:05847e6f86ec7949e60d21e404322a71	createTable tableName=trial_downloads		\N	4.29.2	\N	\N	3511280792
002-admin-users	platform	db/changelog/002-admin-users.xml	2026-07-08 11:48:00.913127	13	EXECUTED	9:f2e1df2da8af70b7639db124a6484462	createTable tableName=admin_users; createIndex indexName=idx_admin_users_role, tableName=admin_users; createIndex indexName=idx_admin_users_brand_id, tableName=admin_users		\N	4.29.2	\N	\N	3511280792
002-admin-users-seed	platform	db/changelog/002-admin-users.xml	2026-07-08 11:48:00.9165	14	EXECUTED	9:2d1765064c97bfc11e401dfff2102c9f	insert tableName=admin_users; insert tableName=admin_users		\N	4.29.2	\N	\N	3511280792
003-add-enabled-column	platform	db/changelog/003-add-enabled-product.xml	2026-07-08 11:48:00.9186	15	EXECUTED	9:21347d8060897254dadaffa48393150c	addColumn tableName=products		\N	4.29.2	\N	\N	3511280792
004-site-settings-theme	platform	db/changelog/004-expand-site-settings.xml	2026-07-08 11:48:00.920421	16	EXECUTED	9:b148bebc5630710980b64fddd5556e74	addColumn tableName=site_settings		\N	4.29.2	\N	\N	3511280792
004-site-settings-navigation	platform	db/changelog/004-expand-site-settings.xml	2026-07-08 11:48:00.922454	17	EXECUTED	9:61fc05cde4978f50c999ac726e631fac	addColumn tableName=site_settings		\N	4.29.2	\N	\N	3511280792
004-site-settings-home-page	platform	db/changelog/004-expand-site-settings.xml	2026-07-08 11:48:00.924614	18	EXECUTED	9:b88a3d38815eb5548b0903880bfb7497	addColumn tableName=site_settings		\N	4.29.2	\N	\N	3511280792
004-site-settings-legal	platform	db/changelog/004-expand-site-settings.xml	2026-07-08 11:48:00.926414	19	EXECUTED	9:7a5ef49e715be7ce255935ef2e632c01	addColumn tableName=site_settings		\N	4.29.2	\N	\N	3511280792
004-site-settings-about	platform	db/changelog/004-expand-site-settings.xml	2026-07-08 11:48:00.928441	20	EXECUTED	9:0e43e67a5c8513bb9c5c3ab17fd0b6d7	addColumn tableName=site_settings		\N	4.29.2	\N	\N	3511280792
004-site-settings-offers	platform	db/changelog/004-expand-site-settings.xml	2026-07-08 11:48:00.930358	21	EXECUTED	9:7851f8ff2b61704771b87388865ec369	addColumn tableName=site_settings		\N	4.29.2	\N	\N	3511280792
004-site-settings-seo-defaults	platform	db/changelog/004-expand-site-settings.xml	2026-07-08 11:48:00.931919	22	EXECUTED	9:84ed7f1d818865244796f9e3fb299c26	addColumn tableName=site_settings		\N	4.29.2	\N	\N	3511280792
005-products-seo-index	platform	db/changelog/005-seo-database-indexes.xml	2026-07-08 11:48:00.935435	23	EXECUTED	9:0d0407f9ff6359006360014de9d2697d	createIndex indexName=idx_products_seo_lookup, tableName=products		\N	4.29.2	\N	\N	3511280792
005-blog-posts-seo-index	platform	db/changelog/005-seo-database-indexes.xml	2026-07-08 11:48:00.937753	24	EXECUTED	9:84c7a63218682bf46c5885bdd95bc20f	createIndex indexName=idx_blog_posts_seo_lookup, tableName=blog_posts		\N	4.29.2	\N	\N	3511280792
005-categories-seo-index	platform	db/changelog/005-seo-database-indexes.xml	2026-07-08 11:48:00.940262	25	EXECUTED	9:17284535eb063d45fc6d7175ae694d24	createIndex indexName=idx_categories_seo_lookup, tableName=categories		\N	4.29.2	\N	\N	3511280792
005-help-articles-seo-index	platform	db/changelog/005-seo-database-indexes.xml	2026-07-08 11:48:00.942634	26	EXECUTED	9:f9eb9a2ea1387dcbd6273a81d0e5801f	createIndex indexName=idx_help_articles_seo_lookup, tableName=help_articles		\N	4.29.2	\N	\N	3511280792
006-url-redirects-table	platform	db/changelog/006-url-redirects.xml	2026-07-08 11:48:00.947875	27	EXECUTED	9:67eeec5192b9c5015580ddea57bac62c	createTable tableName=url_redirects; createIndex indexName=idx_url_redirects_lookup, tableName=url_redirects		\N	4.29.2	\N	\N	3511280792
007-brand-configs	system	db/changelog/007-brand-configs.xml	2026-07-08 11:48:00.956126	28	EXECUTED	9:d335b60e60b82ba7052b1649f386271e	createTable tableName=brand_configs; insert tableName=brand_configs; insert tableName=brand_configs; insert tableName=brand_configs; insert tableName=brand_configs; insert tableName=brand_configs		\N	4.29.2	\N	\N	3511280792
008-brand-dev-port	system	db/changelog/008-brand-dev-port.xml	2026-07-08 11:48:00.961537	29	EXECUTED	9:eb9424bca706d05c7db9f4510ec213cb	addColumn tableName=brand_configs; update tableName=brand_configs; update tableName=brand_configs; update tableName=brand_configs; update tableName=brand_configs; update tableName=brand_configs		\N	4.29.2	\N	\N	3511280792
009-brand-templates	system	db/changelog/009-brand-templates.xml	2026-07-08 11:48:00.965908	30	EXECUTED	9:c052def6784ff19c87af4795996461ad	addColumn tableName=brand_configs; update tableName=brand_configs; update tableName=brand_configs; update tableName=brand_configs; update tableName=brand_configs; update tableName=brand_configs		\N	4.29.2	\N	\N	3511280792
010-brand-logo	antigravity	db/changelog/010-brand-logo.xml	2026-07-08 11:48:00.967876	31	EXECUTED	9:130015ad5779d35f30c3e8e775bd4977	addColumn tableName=brand_configs		\N	4.29.2	\N	\N	3511280792
011-blog-posts-column-fix	system	db/changelog/011-blog-posts-column-fix.xml	2026-07-08 11:48:00.970356	32	EXECUTED	9:63b1f6d0d9058f3a155c89db65d37b99	renameColumn newColumnName=cover_image, oldColumnName=image_url, tableName=blog_posts; renameColumn newColumnName=read_time, oldColumnName=reading_time, tableName=blog_posts		\N	4.29.2	\N	\N	3511280792
012-license-activations-table	system	db/changelog/012-license-activations-table.xml	2026-07-08 11:48:00.976379	33	EXECUTED	9:ef5aff171d975b309e1ee553ae666305	createTable tableName=license_activations; addUniqueConstraint constraintName=uq_license_activations_license_machine, tableName=license_activations		\N	4.29.2	\N	\N	3511280792
013-orders-table	system	db/changelog/013-orders-table.xml	2026-07-08 11:48:00.981989	34	EXECUTED	9:f1471b5d118d968ce8f5ec002311d85c	createTable tableName=orders		\N	4.29.2	\N	\N	3511280792
014-products-column-fix	system	db/changelog/014-products-column-fix.xml	2026-07-08 11:48:00.984184	35	EXECUTED	9:36df5dbfd495062039a1bd2bea939900	renameColumn newColumnName=pricing, oldColumnName=pricing_tiers, tableName=products; addColumn tableName=products		\N	4.29.2	\N	\N	3511280792
015-social-proof-tables	antigravity	db/changelog/015-social-proof.xml	2026-07-08 11:48:00.994972	36	EXECUTED	9:cf279b4b30b9301d67b00c9f4d3cb7c7	createTable tableName=client_logos; createIndex indexName=idx_client_logos_site_id, tableName=client_logos; createTable tableName=testimonials; createIndex indexName=idx_testimonials_site_id, tableName=testimonials		\N	4.29.2	\N	\N	3511280792
016-product-license-comparison	system	db/changelog/016-product-license-comparison.xml	2026-07-08 11:48:00.99655	37	EXECUTED	9:b49a0a5542aabff90162869f824822fb	addColumn tableName=products		\N	4.29.2	\N	\N	3511280792
017-create-format-compatibility	system	db/changelog/017-format-compatibility.xml	2026-07-08 11:48:01.00292	38	EXECUTED	9:9632f48be4c0a773bfd6526e7adc5720	createTable tableName=format_compatibility; createIndex indexName=idx_fc_source_format, tableName=format_compatibility; createIndex indexName=idx_fc_target_format, tableName=format_compatibility		\N	4.29.2	\N	\N	3511280792
017-add-product-format-columns	system	db/changelog/017-format-compatibility.xml	2026-07-08 11:48:01.004982	39	EXECUTED	9:fc44502cfaa793ddde75542b1dc32706	addColumn tableName=products; addColumn tableName=products		\N	4.29.2	\N	\N	3511280792
018-update-brand-a-name	system	db/changelog/018-update-brand-a-name.xml	2026-07-08 11:48:01.006974	40	EXECUTED	9:04f7974b3cf945fa51bdd0efcd785647	update tableName=brand_configs; update tableName=admin_users		\N	4.29.2	\N	\N	3511280792
019-product-capabilities	system	db/changelog/019-product-capabilities.xml	2026-07-08 11:48:01.010766	41	EXECUTED	9:8574efd693067ab0d104acd4e77ccdea	addColumn tableName=products		\N	4.29.2	\N	\N	3511280792
020-create-source-formats	platform	db/changelog/020-global-registry.xml	2026-07-08 11:48:01.018979	42	EXECUTED	9:cec03163743f9b7e7a3c8cbf359fc5da	createTable tableName=source_formats; addUniqueConstraint constraintName=uq_source_format_key_site, tableName=source_formats; createIndex indexName=idx_sf_site_id, tableName=source_formats		\N	4.29.2	\N	\N	3511280792
020-create-target-formats	platform	db/changelog/020-global-registry.xml	2026-07-08 11:48:01.026519	43	EXECUTED	9:67b783048680212412787432fe64ae0e	createTable tableName=target_formats; addUniqueConstraint constraintName=uq_target_format_key_site, tableName=target_formats; createIndex indexName=idx_tf_site_id, tableName=target_formats		\N	4.29.2	\N	\N	3511280792
020-create-supported-clients	platform	db/changelog/020-global-registry.xml	2026-07-08 11:48:01.033309	44	EXECUTED	9:8564dc2b91de5bd207b95b8ab1f9a477	createTable tableName=supported_clients; addUniqueConstraint constraintName=uq_client_key_site, tableName=supported_clients; createIndex indexName=idx_sc_site_id, tableName=supported_clients		\N	4.29.2	\N	\N	3511280792
020-create-key-features	platform	db/changelog/020-global-registry.xml	2026-07-08 11:48:01.040421	45	EXECUTED	9:3a9b14853284dded9950e50e4e83571f	createTable tableName=key_features; addUniqueConstraint constraintName=uq_feature_key_site, tableName=key_features; createIndex indexName=idx_kf_site_id, tableName=key_features		\N	4.29.2	\N	\N	3511280792
021-add-supports-multiple-accounts-source	platform	db/changelog/021-add-registry-multi-account.xml	2026-07-08 11:48:01.043902	46	EXECUTED	9:674d1f7bffcc96d74a82c40e12093d75	addColumn tableName=source_formats		\N	4.29.2	\N	\N	3511280792
021-add-supports-multiple-accounts-target	platform	db/changelog/021-add-registry-multi-account.xml	2026-07-08 11:48:01.045876	47	EXECUTED	9:698d478395a0e4eaa88f16d48e998892	addColumn tableName=target_formats		\N	4.29.2	\N	\N	3511280792
022-site-settings-careers	platform	db/changelog/022-site-settings-careers.xml	2026-07-08 11:48:01.047502	48	EXECUTED	9:f51066efe87534187f4c19b5dc11253c	addColumn tableName=site_settings		\N	4.29.2	\N	\N	3511280792
023-career-positions	platform	db/changelog/023-career-positions.xml	2026-07-08 11:48:01.052436	49	EXECUTED	9:b9dc45432579167aa37ff7ec3454a792	createTable tableName=career_positions		\N	4.29.2	\N	\N	3511280792
024-site-settings-clients	platform	db/changelog/024-site-settings-clients.xml	2026-07-08 11:48:01.056212	50	EXECUTED	9:84b3e981a4e8487148a54b09bc6c60a4	addColumn tableName=site_settings; addColumn tableName=client_logos		\N	4.29.2	\N	\N	3511280792
025-product-install-urls	platform	db/changelog/025-product-install-urls.xml	2026-07-08 11:48:01.058296	51	EXECUTED	9:42b8a7638726bfa570a6dc1560c6188a	addColumn tableName=products		\N	4.29.2	\N	\N	3511280792
026-link-faqs-guides-to-products	platform	db/changelog/026-link-faqs-guides-to-products.xml	2026-07-08 11:48:01.06043	52	EXECUTED	9:813e2906256bd7fd822dc58117660ae3	addColumn tableName=faqs; addColumn tableName=help_articles		\N	4.29.2	\N	\N	3511280792
027-faq-guide-multiple-products	platform	db/changelog/027-faq-guide-multiple-products.xml	2026-07-08 11:48:01.06219	53	EXECUTED	9:9d49ee2926149c4787f96735ee47419f	addColumn tableName=faqs; addColumn tableName=help_articles		\N	4.29.2	\N	\N	3511280792
028-category-multiple-products	platform	db/changelog/028-category-multiple-products.xml	2026-07-08 11:48:01.063512	54	EXECUTED	9:c69be823d3f12f8908c6dd558f1541ab	addColumn tableName=categories		\N	4.29.2	\N	\N	3511280792
029-testimonials-product-ids	platform	db/changelog/029-social-proof-product-ids.xml	2026-07-08 11:48:01.065002	55	EXECUTED	9:aaa780609b31a2e64573aab4f40cffc7	addColumn tableName=testimonials		\N	4.29.2	\N	\N	3511280792
029b-client-logos-product-ids	platform	db/changelog/029-social-proof-product-ids.xml	2026-07-08 11:48:01.066569	56	EXECUTED	9:8dc251da8ff7e898e7cbe3d3008d2841	addColumn tableName=client_logos		\N	4.29.2	\N	\N	3511280792
030-blog-posts-product-ids	platform	db/changelog/030-blog-product-ids.xml	2026-07-08 11:48:01.068186	57	EXECUTED	9:a4b5ca055d1931ca71bdb0e958382e38	addColumn tableName=blog_posts		\N	4.29.2	\N	\N	3511280792
031-trial-downloads-product-id	platform	db/changelog/031-trial-downloads-product-id.xml	2026-07-08 11:48:01.077663	58	EXECUTED	9:1f08f320286e30520e79fda15df42f3e	addColumn tableName=trial_downloads; sql		\N	4.29.2	\N	\N	3511280792
032-migrationuncle-brand	system	db/changelog/032-migrationuncle-brand.xml	2026-07-08 11:48:01.079531	59	EXECUTED	9:923ce2d9be3150fe9ac5b02e7b6ba404	insert tableName=brand_configs		\N	4.29.2	\N	\N	3511280792
033-apexbyte-brand	system	db/changelog/033-apexbyte-brand.xml	2026-07-08 11:48:01.081687	60	EXECUTED	9:4a22847a143eaf7a90015c6aa3bbdbd6	insert tableName=brand_configs		\N	4.29.2	\N	\N	3511280792
034-remove-old-brands	system	db/changelog/034-remove-old-brands.xml	2026-07-08 11:48:01.084322	61	EXECUTED	9:8c0f2d0f819337b2eadfacd33ad063f2	delete tableName=admin_users; delete tableName=admin_users; delete tableName=brand_configs; delete tableName=brand_configs		\N	4.29.2	\N	\N	3511280792
035-product-installer-url	platform	db/changelog/035-product-installer-url.xml	2026-07-10 18:20:01.488983	62	EXECUTED	9:e24fe8def25fc9e36a20db6f996bef34	addColumn tableName=products		\N	4.29.2	\N	\N	3707601472
036-create-coupons-table	antigravity	db/changelog/036-create-coupons-table.xml	2026-07-11 13:00:41.74737	63	EXECUTED	9:7ed45eb4663f0df085a6695210960921	createTable tableName=coupons; addUniqueConstraint constraintName=uq_coupon_code_site, tableName=coupons		\N	4.29.2	\N	\N	3755041724
037-billing-compliance-fields	antigravity	db/changelog/037-billing-compliance-fields.xml	2026-07-11 13:00:41.758237	64	EXECUTED	9:5c555640cb34b5bee76c9f13c42a32fa	addColumn tableName=orders		\N	4.29.2	\N	\N	3755041724
038-add-offline-column	platform	db/changelog/038-add-offline-column.xml	2026-07-15 08:11:15.827917	65	EXECUTED	9:eb801940a5c750f1d13984ec41d26c06	addColumn tableName=license_keys		\N	4.29.2	\N	\N	4103075805
039-populate-brand-a-legal-pages	platform	db/changelog/039-populate-brand-a-legal-pages.xml	2026-07-15 12:51:17.136932	66	EXECUTED	9:03e0fa353f6e58bdbee9987dd12a0ef5	sql		\N	4.29.2	\N	\N	4119877107
040-add-category-to-source-formats	platform	db/changelog/040-add-format-category.xml	2026-07-16 05:50:18.281571	67	EXECUTED	9:68bc7838bcf7987fd84c769099e886e5	addColumn tableName=source_formats		\N	4.29.2	\N	\N	4181018262
040-add-category-to-target-formats	platform	db/changelog/040-add-format-category.xml	2026-07-16 05:50:18.287892	68	EXECUTED	9:5313fb4ea3efe5345b75f69dddb64db7	addColumn tableName=target_formats		\N	4.29.2	\N	\N	4181018262
040-backfill-source-format-categories	platform	db/changelog/040-add-format-category.xml	2026-07-16 05:50:18.299576	69	EXECUTED	9:6cdbb5ac4d1435afd50173e490b4dfe9	update tableName=source_formats; update tableName=source_formats; update tableName=source_formats; update tableName=source_formats; update tableName=source_formats; update tableName=source_formats; update tableName=source_formats; update tableName...		\N	4.29.2	\N	\N	4181018262
040-backfill-target-format-categories	platform	db/changelog/040-add-format-category.xml	2026-07-16 05:50:18.313351	70	EXECUTED	9:55ef6671a52b21e3fdde7bbeb2711a67	update tableName=target_formats; update tableName=target_formats; update tableName=target_formats; update tableName=target_formats; update tableName=target_formats; update tableName=target_formats; update tableName=target_formats; update tableName...		\N	4.29.2	\N	\N	4181018262
041-update-official-format-icons	platform	db/changelog/041-update-official-format-icons.xml	2026-07-16 05:57:27.550497	71	EXECUTED	9:5ff6a65348ee8fab02925a933e1b78e6	update tableName=source_formats; update tableName=target_formats; update tableName=source_formats; update tableName=target_formats; update tableName=source_formats; update tableName=target_formats; update tableName=source_formats; update tableName...		\N	4.29.2	\N	\N	4181447492
042-trust-conversion-fields	system	db/changelog/042-trust-conversion-fields.xml	2026-07-16 15:56:53.252222	72	EXECUTED	9:249fa9b86f14440898820fff42cc254b	addColumn tableName=site_settings; addColumn tableName=site_settings; addColumn tableName=site_settings; addColumn tableName=site_settings; addColumn tableName=site_settings; addColumn tableName=site_settings		\N	4.29.2	\N	\N	4217413221
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
\.


--
-- Data for Name: faqs; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.faqs (id, question, answer, category, site_id, product_id, product_ids) FROM stdin;
faq-apex-1	Do you offer technical support during migrations?	Yes, all our Enterprise licenses come with 24/7 priority support and dedicated migration engineers.	General	apexbyte	apexbyte-exchange-migrator	[]
faq-apex-2	Can I try the software before buying?	Absolutely. We offer fully-functional free trials for all our products.	General	apexbyte	\N	[]
faq-apex-3	What is your refund policy?	We offer a strict 30-day money-back guarantee if the software fails to perform the described tasks and our support team cannot resolve the issue.	General	apexbyte	\N	[]
faq-apex-4	Are my backups encrypted?	Yes, ApexByte Cloud Backup Pro uses AES-256 military-grade encryption both in-transit and at-rest.	Security	apexbyte	apexbyte-cloud-backup-pro	[]
faq-apex-5	Does the SQL migrator support stored procedures?	Yes, our schema translation AI attempts to convert stored procedures between major dialects, though complex logic may require manual review.	Technical	apexbyte	apexbyte-sql-migrator	[]
brandD-f1	How do I get support for Brand D Backup Suite?	You can reach out to our team 24/7 via the help section in Brand D.	general	brandD	\N	[]
brandE-f1	How do I get support for Brand E PDF Converter?	You can reach out to our team 24/7 via the help section in Brand E.	general	brandE	\N	[]
faq-mgu-1	I am not very good with computers. Is this hard to use?	Not at all! We designed all of our tools to be as simple as possible. Plus, our friendly support team is always here to help you step-by-step.	General	migrationuncle	\N	["uncle-pst-to-gmail", "uncle-cloud-migration-kit"]
faq-mgu-2	Will this delete my original emails?	No way! We only read your original files and create copies in the new location. Your original data is always perfectly safe.	Safety	migrationuncle	\N	["uncle-pst-to-gmail", "uncle-duplicate-cleaner", "uncle-cloud-migration-kit"]
faq-mgu-3	What if the tool doesn't work for me?	We want you to be happy. If our tool doesn't solve your problem and we can't help fix it, we'll give you a full refund within 30 days.	General	migrationuncle	\N	["uncle-pst-to-gmail", "uncle-ost-recovery", "uncle-mbox-to-pst"]
faq-mgu-4	How fast is the conversion process?	It depends on your file size, but our tools are highly optimized. Typically, it can process 1GB of data in just a few minutes.	Performance	migrationuncle	\N	["uncle-mbox-to-pst", "uncle-ost-to-pst"]
faq-mgu-5	Does Duplicate Cleaner delete emails permanently?	By default, it moves duplicates to a 'Deleted Items' folder so you can review them. You can configure it to permanently delete if you prefer.	Features	migrationuncle	\N	["uncle-duplicate-cleaner"]
faq-mgu-6	Can it recover emails that were permanently deleted?	The OST Recovery tool can sometimes recover 'hard-deleted' items if the space hasn't been overwritten in the file yet.	Features	migrationuncle	\N	["uncle-ost-recovery"]
faq-mgu-7	Where are my backups stored?	Email Backup Pro stores your backups locally on your computer or any external hard drive you specify. We don't keep your data on our servers.	Privacy	migrationuncle	\N	["uncle-email-backup-pro"]
faq-mgu-8	Is the EML Viewer actually free?	Yes! 100% free, no ads, no hidden costs. It's our way of helping out the community.	Pricing	migrationuncle	\N	["uncle-eml-viewer"]
faq-mgu-9	Does it maintain folder hierarchy?	Absolutely. The cloud migration kit accurately maps your local folder structure directly to your cloud mailbox.	Features	migrationuncle	\N	["uncle-cloud-migration-kit", "uncle-pst-to-gmail"]
faq-mgu-10	Can I install this on a Mac?	Currently, our tools are designed for Windows operating systems (Windows 10 and 11).	Compatibility	migrationuncle	\N	["uncle-pst-to-gmail", "uncle-mbox-to-pst"]
8f939c4b-14e7-4676-ae6f-9caeb7f59615	Can I convert large PST files?	Yes, our software has no file size limit and can convert large PST files without data loss.	Product: Share point Migration	brandA	PRM-MIG-2026-004	["PRM-MIG-2026-004"]
99bb8c23-6ff8-4d3c-80f3-aab19a5d08c9	Can I converdfsadft large PST files?	Yes, our software has no file size limit and can convert large PST files without data loss.	Product: PST Convertor	brandA	PRM-MIG-2026-001	["PRM-MIG-2026-001"]
\.


--
-- Data for Name: format_compatibility; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.format_compatibility (id, source_format, target_format, compatibility_score, match_type, notes) FROM stdin;
pst-to-ost	pst	ost	95	EXACT	Same Microsoft binary format family — direct conversion supported
ost-to-pst	ost	pst	95	EXACT	Exchange offline cache to Outlook archive — p6 (OST Recovery) handles this
pst-to-gmail	pst	gmail	88	SIMILAR	p1 migrates PST files directly to Gmail accounts
outlook-to-gmail	outlook	gmail	88	SIMILAR	p1 migrates live Outlook mailbox to Gmail
pst-to-google-workspace	pst	google_workspace	85	SIMILAR	p1/p5 migrate PST to Google Workspace/G Suite
ost-to-gmail	ost	gmail	78	SIMILAR	OST files can be converted via PST bridge — indirect path
o365-to-gws	office365	google_workspace	92	EXACT	p5 directly migrates Office 365 to Google Workspace
o365-to-gmail	office365	gmail	88	SIMILAR	p5 migrates O365 Exchange Online emails to Gmail
exchange-to-gws	exchange_online	google_workspace	90	EXACT	p5 supports Exchange Online to Google Workspace
gmail-to-pst	gmail	pst	82	SIMILAR	p4 (Gmail Backup) exports Gmail directly to PST
gmail-to-mbox	gmail	mbox	78	SIMILAR	p4 exports Gmail to MBOX format
gmail-to-eml	gmail	eml	75	SIMILAR	p4 exports Gmail to individual EML files
gws-to-pst	google_workspace	pst	78	SIMILAR	p4 supports Google Workspace backup to PST
pst-to-mbox	pst	mbox	72	COMPATIBLE	p3 (PST to MBOX Converter) handles this directly
pst-to-eml	pst	eml	70	COMPATIBLE	Can extract individual EML files from PST
mbox-to-pst	mbox	pst	65	COMPATIBLE	Reverse MBOX→PST conversion supported
eml-to-pst	eml	pst	62	COMPATIBLE	Bulk EML to PST aggregation supported
ost-to-eml	ost	eml	62	COMPATIBLE	p6 (OST Recovery) exports recovered data to EML
ost-to-msg	ost	msg	60	COMPATIBLE	p6 exports recovered data to MSG format
ost-to-mbox	ost	mbox	55	COMPATIBLE	Indirect: OST→PST→MBOX path available
o365-to-pst	office365	pst	72	COMPATIBLE	p2 (Office 365 Backup) can save backups as PST files
outlook-to-google-workspace	outlook	google_workspace	82	SIMILAR	p1 supports Outlook (live) to Google Workspace migration
o365-to-mbox	office365	mbox	55	COMPATIBLE	Indirect migration path via PST intermediary
gmail-to-google-workspace	gmail	google_workspace	70	COMPATIBLE	Same Google ecosystem — user/domain consolidation
\.


--
-- Data for Name: help_articles; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.help_articles (id, slug, title, excerpt, content, category, tags, published_at, helpful, not_helpful, site_id, product_id, product_ids) FROM stdin;
help-apex-1	exchange-migration-best-practices	Best Practices for Zero-Downtime Exchange Migrations	\N	A comprehensive guide on planning, staging, and executing a migration from on-prem Exchange to Microsoft 365. Always run a delta sync after the final cutover.	Migration	["Exchange", "Office365", "Enterprise"]	\N	\N	\N	apexbyte	\N	[]
help-apex-2	configuring-cloud-backup-schedules	How to Configure Optimal Cloud Backup Schedules	\N	Learn how to balance RPO/RTO requirements with storage costs by setting up tiered retention policies in ApexByte Cloud Backup Pro.	Backup	["Cloud", "AWS", "Azure"]	\N	\N	\N	apexbyte	\N	[]
help-apex-3	translating-oracle-to-postgres	Translating Oracle Schemas to PostgreSQL	\N	A deep dive into how ApexByte handles specific Oracle data types like NUMBER and VARCHAR2 when migrating to PostgreSQL.	Database	["Oracle", "PostgreSQL", "SQL"]	\N	\N	\N	apexbyte	\N	[]
help-apex-4	troubleshooting-pdf-fonts	Troubleshooting Missing Fonts in PDF Conversions	\N	If your converted Word document looks different from the PDF, ensure the original fonts are installed on your system or enable 'Embed Missing Fonts' in the settings.	Converters	["PDF", "Word", "Formatting"]	\N	\N	\N	apexbyte	\N	[]
help-apex-5	removing-duplicates-safely	How to Remove Outlook Duplicates Safely	\N	Always run a backup before removing duplicates. Use our 'Simulate' mode first to review the items that will be deleted.	Maintenance	["Outlook", "Cleanup"]	\N	\N	\N	apexbyte	\N	[]
help-mgu-1	how-to-find-pst-file	How to find your Outlook PST file	\N	If you're not sure where Outlook keeps your data, don't worry! Open Outlook, go to File > Account Settings, and click the Data Files tab. The location of your file is listed right there.	Getting Started	["Outlook", "PST", "Beginner"]	\N	\N	\N	migrationuncle	\N	["uncle-pst-to-gmail"]
help-mgu-2	what-is-an-ost-file	What is an OST file anyway?	\N	An OST file is an 'Offline Storage Table'. It's basically a cached copy of your mailbox when you use an Exchange or IMAP account. It lets you read your mail even when your internet is down.	Learning	["OST", "Information"]	\N	\N	\N	migrationuncle	\N	["uncle-ost-recovery", "uncle-ost-to-pst"]
help-mgu-3	preventing-duplicate-emails	How to prevent duplicate emails in the future	\N	Duplicates often happen when you drag and drop folders incorrectly or sync the same account on multiple devices improperly. Always use IMAP instead of POP3!	Best Practices	["Clean Inbox", "Tips"]	\N	\N	\N	migrationuncle	\N	["uncle-duplicate-cleaner"]
help-mgu-4	best-backup-strategy	The 3-2-1 Backup Rule	\N	Keep 3 copies of your data, on 2 different media, with 1 offsite. Email Backup Pro can help you automate the local backups.	Learning	["Backup", "Security"]	\N	\N	\N	migrationuncle	\N	["uncle-email-backup-pro"]
help-mgu-5	exporting-from-thunderbird	Exporting your mail from Mozilla Thunderbird	\N	Thunderbird uses the MBOX format. You can find your profile folder by clicking Help > Troubleshooting Information > Open Folder.	Getting Started	["MBOX", "Thunderbird"]	\N	\N	\N	migrationuncle	\N	["uncle-mbox-to-pst"]
help-mgu-6	migrating-to-office-365	Checklist for Migrating to Office 365	\N	Make sure you have your admin credentials, list of mailboxes, and inform your users about the downtime before starting the migration.	Migration	["Cloud", "O365"]	\N	\N	\N	migrationuncle	\N	["uncle-cloud-migration-kit"]
9e3d9663-b317-46e4-b9de-d7bc2bf9e649	share-point-migration-user-guide	User Guide: How to Use Share point Migration	Step-by-step configuration and usage guide for Share point Migration.	### 1. Download & Install\nDownload the software and install it on your PC.\n\n### 2. Add PST File\nLaunch the software and select the Outlook PST file you want to convert.\n\n### 3. Select Output\nChoose the output format and destination path.\n\n### 4. Convert & Export\nClick Convert to export your mailbox items.	Product Guide	["guide", "product", "share point migration"]	2026-07-07	0	0	brandA	PRM-MIG-2026-004	["PRM-MIG-2026-004"]
94ebe006-c520-4861-a776-b3f5867f86b9	pst-converter-user-guide	User Guide: How to Use PST Convertor	Step-by-step configuration and usage guide for PST Convertor.	### 1. Download & Install\nDownload the software and install it on your PC.\n\n### 2. Add PST File\nLaunch the software and select the Outlook PST file you want to convert.\n\n### 3. Select Output\nChoose the output format and destination path.\n\n### 4. Convert & Export\nClick Convert to export your mailbox items.	Product Guide	["guide", "product", "pst convertor"]	2026-07-07	0	0	brandA	PRM-MIG-2026-001	["PRM-MIG-2026-001"]
\.


--
-- Data for Name: inquiries; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.inquiries (id, name, email, subject, message, created_at, site_id) FROM stdin;
\.


--
-- Data for Name: key_features; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.key_features (id, feature_key, name, description, site_id) FROM stdin;
apexbyte-kf-batch	supportsMultipleAccounts	Batch Migration	Perform multiple migrations simultaneously	apexbyte
brandD-kf-batch	supportsMultipleAccounts	Batch Migration	Perform multiple migrations simultaneously	brandD
brandE-kf-batch	supportsMultipleAccounts	Batch Migration	Perform multiple migrations simultaneously	brandE
migrationuncle-kf-batch	supportsMultipleAccounts	Batch Migration	Perform multiple migrations simultaneously	migrationuncle
kf-batch	supportsMultipleAccounts	Batch Migration	Perform multiple migrations simultaneously	brandA
kf-filters	supportsBatchCsv	Batch CSV Import	Filter and import migrations via a CSV file list	brandA
kf-preview	supportsIncrementalSync	Incremental Sync	Migrate only new or modified items on subsequent runs	brandA
kf-impersonation	supportsImpersonation	Domain Impersonation	Administrator level domain impersonation for office migrations	brandA
kf-multiple-files	supportsMultipleFiles	Multiple Files Support	Allows selecting and converting multiple files simultaneously	brandA
kf-extract-emails	extractEmails	Extract Emails	Extracts and migrates all email folders (Inbox, Sent, Drafts, etc.)	brandA
kf-extract-contacts	extractContacts	Extract Contacts	Extracts and migrates contact lists, address books, and distribution lists	brandA
kf-extract-calendars	extractCalendars	Extract Calendars	Extracts and migrates calendar events, schedules, and meetings	brandA
kf-batch-bA	supportsBatchMigration	Batch Migration	Migrate multiple mailboxes or files simultaneously to save time	brandA
kf-incremental-bA	supportsIncremental	Incremental Sync	Migrate only new or modified items on subsequent runs to prevent duplicates	brandA
kf-folder-filter-bA	supportsFolderFilter	Folder Selection	Select specific folders (Inbox, Sent, Drafts) to include or exclude	brandA
kf-date-filter-bA	supportsDateFilter	Date Range Filter	Migrate emails falling within a specific date range	brandA
kf-hierarchy-bA	preservesHierarchy	Preserve Hierarchy	Maintains the exact folder and subfolder structure during migration	brandA
kf-csv-mapping-bA	supportsCsvMapping	CSV Mapping	Map source and destination accounts automatically using a CSV file	brandA
kf-split-pst-bA	supportsSplitPst	Split Large Files	Automatically split oversized output PST files by size (GB/MB)	brandA
kf-remove-dupes-bA	removesDuplicates	Remove Duplicates	Detect and skip duplicate emails based on To, From, Subject, and Date	brandA
kf-extract-attachments-bA	extractsAttachments	Extract Attachments	Option to extract attachments separately to a local folder	brandA
kf-preview-bA	supportsPreview	Preview Mode	Preview emails and attachments within the software before migration	brandA
kf-reports-bA	generatesReports	Detailed Reports	Generates detailed CSV/HTML migration logs for compliance and auditing	brandA
kf-contacts-cals-bA	migratesContactsCals	Contacts & Calendars	Migrates address books, distribution lists, and calendar events intact	brandA
kf-duplicate-cleanup	supportsDuplicateCleanup	Duplicate Cleanup	Identify and remove duplicate emails, files or folders during processing	brandA
kf-deep-scan	supportsDeepScan	Deep Scan Mode	Sector-by-sector scan for corrupted or damaged database files	brandA
kf-folder-tree	supportsFolderLock	Folder Tree Locking	Preserve exact hierarchical folder structures during conversion	brandA
kf-split-files	supportsSplitFiles	Split Large Files	Automatically split large output files into smaller target segments	brandA
kf-merge-files	supportsMergeFiles	Merge Files	Merge multiple source files into a single unified output file	brandA
kf-pause-resume	supportsPauseResume	Pause & Resume	Allows pausing and resuming the conversion process mid-operation	brandA
kf-log-report	supportsLogReports	Conversion Log Reports	Generates and saves TXT log report summaries after completion	brandA
\.


--
-- Data for Name: legacy_license_activations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.legacy_license_activations (id, license_key_id, hardware_fingerprint, device_name, activated_at, last_check_in) FROM stdin;
\.


--
-- Data for Name: license_activations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.license_activations (id, license_id, machine_id, machine_name, os_name, ip_address, activated_at, last_checked_at) FROM stdin;
25	66	mach-apx-101	Developer's MacBook Pro	macOS Sequoia 15.2	192.168.1.15	2026-06-25 16:57:49.294227+00	2026-07-10 13:57:49.29427+00
26	67	mach-apx-201	Marketing Win11 Desktop	Windows 11 Enterprise	10.0.0.122	2026-06-10 16:57:49.294413+00	2026-07-09 16:57:49.294422+00
27	67	mach-apx-202	CEO ThinkPad	Windows 11 Pro	10.0.0.45	2026-07-05 16:57:49.294631+00	2026-07-10 16:12:49.294644+00
28	74	mach-pstd-101	Developer's MacBook Pro	macOS Sequoia 15.2	192.168.1.15	2026-06-25 16:57:49.45729+00	2026-07-10 13:57:49.457295+00
29	75	mach-pstd-201	Marketing Win11 Desktop	Windows 11 Enterprise	10.0.0.122	2026-06-10 16:57:49.457311+00	2026-07-09 16:57:49.457313+00
30	75	mach-pstd-202	CEO ThinkPad	Windows 11 Pro	10.0.0.45	2026-07-05 16:57:49.457316+00	2026-07-10 16:12:49.457317+00
31	82	mach-pste-101	Developer's MacBook Pro	macOS Sequoia 15.2	192.168.1.15	2026-06-25 16:57:49.562139+00	2026-07-10 13:57:49.562151+00
32	83	mach-pste-201	Marketing Win11 Desktop	Windows 11 Enterprise	10.0.0.122	2026-06-10 16:57:49.56216+00	2026-07-09 16:57:49.562162+00
33	83	mach-pste-202	CEO ThinkPad	Windows 11 Pro	10.0.0.45	2026-07-05 16:57:49.562165+00	2026-07-10 16:12:49.562166+00
34	90	mach-mgu-101	Developer's MacBook Pro	macOS Sequoia 15.2	192.168.1.15	2026-06-25 16:57:49.729991+00	2026-07-10 13:57:49.729998+00
35	91	mach-mgu-201	Marketing Win11 Desktop	Windows 11 Enterprise	10.0.0.122	2026-06-10 16:57:49.730006+00	2026-07-09 16:57:49.730007+00
36	91	mach-mgu-202	CEO ThinkPad	Windows 11 Pro	10.0.0.45	2026-07-05 16:57:49.73001+00	2026-07-10 16:12:49.730011+00
\.


--
-- Data for Name: license_keys; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.license_keys (id, activation_key, order_id, product_id, pricing_tier_name, customer_email, status, max_devices, created_at, expires_at, site_id, is_offline_capable) FROM stdin;
\.


--
-- Data for Name: licenses; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.licenses (id, license_key, status, license_type, expires_at, max_activations, created_at, site_id) FROM stdin;
66	APX-ELITE-AAAE-AAAM-AAAD	ACTIVE	STANDARD	2027-07-10 16:57:49.293919+00	2	2026-07-10 16:57:49.296233+00	apexbyte
67	APX-ELITE-BBBB-BBBJ-BBBA	ACTIVE	BUSINESS	2028-07-10 16:57:49.294331+00	3	2026-07-10 16:57:49.315163+00	apexbyte
68	APX-ELITE-CCCP-CCCG-CCCO	REVOKED	ENTERPRISE	2029-07-10 16:57:49.294679+00	10	2026-07-10 16:57:49.318773+00	apexbyte
69	APX-ELITE-DDDM-DDDD-DDDL	ACTIVE	ENTERPRISE	2031-07-10 16:57:49.294691+00	10	2026-07-10 16:57:49.320121+00	apexbyte
70	APX-ELITE-EEEJ-EEER-EEEI	ACTIVE	BUSINESS	2029-07-10 16:57:49.294696+00	5	2026-07-10 16:57:49.320825+00	apexbyte
71	APX-ELITE-FFFG-FFFO-FFFF	ACTIVE	STANDARD	2027-07-10 16:57:49.294701+00	3	2026-07-10 16:57:49.321653+00	apexbyte
72	APX-ELITE-GGGU-GGGL-GGGT	EXPIRED	STANDARD	2026-06-30 16:57:49.294718+00	3	2026-07-10 16:57:49.322422+00	apexbyte
73	APX-ELITE-HHHR-HHHI-HHHQ	REVOKED	ENTERPRISE	2031-07-10 16:57:49.294726+00	10	2026-07-10 16:57:49.323114+00	apexbyte
74	PSTD-ELITE-AAAE-AAAM-AAAD	ACTIVE	STANDARD	2027-07-10 16:57:49.457274+00	2	2026-07-10 16:57:49.457777+00	brandD
75	PSTD-ELITE-BBBB-BBBJ-BBBA	ACTIVE	BUSINESS	2028-07-10 16:57:49.457307+00	3	2026-07-10 16:57:49.460787+00	brandD
76	PSTD-ELITE-CCCP-CCCG-CCCO	REVOKED	ENTERPRISE	2029-07-10 16:57:49.457321+00	10	2026-07-10 16:57:49.463733+00	brandD
77	PSTD-ELITE-DDDM-DDDD-DDDL	ACTIVE	ENTERPRISE	2031-07-10 16:57:49.457323+00	10	2026-07-10 16:57:49.464874+00	brandD
78	PSTD-ELITE-EEEJ-EEER-EEEI	ACTIVE	BUSINESS	2029-07-10 16:57:49.457326+00	5	2026-07-10 16:57:49.465559+00	brandD
79	PSTD-ELITE-FFFG-FFFO-FFFF	ACTIVE	STANDARD	2027-07-10 16:57:49.457328+00	3	2026-07-10 16:57:49.466365+00	brandD
80	PSTD-ELITE-GGGU-GGGL-GGGT	EXPIRED	STANDARD	2026-06-30 16:57:49.457331+00	3	2026-07-10 16:57:49.467822+00	brandD
81	PSTD-ELITE-HHHR-HHHI-HHHQ	REVOKED	ENTERPRISE	2031-07-10 16:57:49.457333+00	10	2026-07-10 16:57:49.468418+00	brandD
82	PSTE-ELITE-AAAE-AAAM-AAAD	ACTIVE	STANDARD	2027-07-10 16:57:49.562123+00	2	2026-07-10 16:57:49.562515+00	brandE
83	PSTE-ELITE-BBBB-BBBJ-BBBA	ACTIVE	BUSINESS	2028-07-10 16:57:49.562157+00	3	2026-07-10 16:57:49.564945+00	brandE
84	PSTE-ELITE-CCCP-CCCG-CCCO	REVOKED	ENTERPRISE	2029-07-10 16:57:49.562206+00	10	2026-07-10 16:57:49.567575+00	brandE
85	PSTE-ELITE-DDDM-DDDD-DDDL	ACTIVE	ENTERPRISE	2031-07-10 16:57:49.56221+00	10	2026-07-10 16:57:49.568225+00	brandE
86	PSTE-ELITE-EEEJ-EEER-EEEI	ACTIVE	BUSINESS	2029-07-10 16:57:49.562221+00	5	2026-07-10 16:57:49.568876+00	brandE
87	PSTE-ELITE-FFFG-FFFO-FFFF	ACTIVE	STANDARD	2027-07-10 16:57:49.562224+00	3	2026-07-10 16:57:49.569453+00	brandE
88	PSTE-ELITE-GGGU-GGGL-GGGT	EXPIRED	STANDARD	2026-06-30 16:57:49.562226+00	3	2026-07-10 16:57:49.570487+00	brandE
89	PSTE-ELITE-HHHR-HHHI-HHHQ	REVOKED	ENTERPRISE	2031-07-10 16:57:49.562229+00	10	2026-07-10 16:57:49.571226+00	brandE
90	MGU-ELITE-AAAE-AAAM-AAAD	ACTIVE	STANDARD	2027-07-10 16:57:49.729959+00	2	2026-07-10 16:57:49.73035+00	migrationuncle
91	MGU-ELITE-BBBB-BBBJ-BBBA	ACTIVE	BUSINESS	2028-07-10 16:57:49.730002+00	3	2026-07-10 16:57:49.732551+00	migrationuncle
92	MGU-ELITE-CCCP-CCCG-CCCO	REVOKED	ENTERPRISE	2029-07-10 16:57:49.730014+00	10	2026-07-10 16:57:49.734283+00	migrationuncle
93	MGU-ELITE-DDDM-DDDD-DDDL	ACTIVE	ENTERPRISE	2031-07-10 16:57:49.730058+00	10	2026-07-10 16:57:49.735131+00	migrationuncle
94	MGU-ELITE-EEEJ-EEER-EEEI	ACTIVE	BUSINESS	2029-07-10 16:57:49.730061+00	5	2026-07-10 16:57:49.735778+00	migrationuncle
95	MGU-ELITE-FFFG-FFFO-FFFF	ACTIVE	STANDARD	2027-07-10 16:57:49.730062+00	3	2026-07-10 16:57:49.736521+00	migrationuncle
96	MGU-ELITE-GGGU-GGGL-GGGT	EXPIRED	STANDARD	2026-06-30 16:57:49.730064+00	3	2026-07-10 16:57:49.73721+00	migrationuncle
97	MGU-ELITE-HHHR-HHHI-HHHQ	REVOKED	ENTERPRISE	2031-07-10 16:57:49.730066+00	10	2026-07-10 16:57:49.738286+00	migrationuncle
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.orders (id, order_id, customer_email, product_id, product_name, pricing_tier_name, amount, currency, payment_status, payment_method, activation_key, created_at, site_id, billing_name, billing_company, billing_address, billing_city, billing_state, billing_zip, billing_country, tax_id, tax_amount, tax_rate) FROM stdin;
3e702437-ba06-4a07-886f-3949f9dc03c8	ORD-534285	test_online@example.com	PRM-MIG-2026-002	MBOX to PST Converter	Personal License	29	USD	PAID	STRIPE	DMP-AAF5-AAAB-385A	2026-07-15 08:11:38.984672	brandA	\N	\N	\N	\N	\N	\N	\N	\N	0	0
eda7293d-dacd-448c-89b1-6b3ac1f9932e	ORD-772108	test_offline@example.com	PRM-MIG-2026-002	MBOX to PST Converter	Personal License	29	USD	PAID	STRIPE	PST-ELITE-PXWM-YRDC-ADNE	2026-07-15 08:11:41.595804	brandA	\N	\N	\N	\N	\N	\N	\N	\N	0	0
521fd55e-5802-4b80-87ad-13d10dbe619d	ORD-140976	user_online@example.com	PRM-MIG-2026-002	MBOX to PST Converter	Personal License	29	USD	PAID	STRIPE	DMP-D03F-729B-5E64	2026-07-15 08:15:08.292177	brandA	\N	\N	\N	\N	\N	\N	\N	\N	0	0
156dfcd6-d4de-4886-a210-ab7ee380166e	ORD-929771	user_offline@example.com	PRM-MIG-2026-002	MBOX to PST Converter	Personal License	29	USD	PAID	STRIPE	PST-ELITE-UEYH-QFYB-TVQP	2026-07-15 08:15:10.658002	brandA	\N	\N	\N	\N	\N	\N	\N	\N	0	0
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.products (id, slug, name, short_description, description, category, tags, rating, review_count, downloads, badge, version, last_updated, trial_download_url, features, platforms, supported_formats, screenshots, pricing, seo, system_requirements, how_it_works, reviews, faqs, site_id, enabled, related_product_ids, license_comparison, source_formats, target_formats, capabilities, installation_success_url, uninstallation_success_url, installer_url) FROM stdin;
apexbyte-exchange-migrator	apexbyte-exchange-migrator	ApexByte Exchange Migrator	Seamlessly migrate on-premise Exchange to Microsoft 365.	Our flagship product for enterprise Exchange migrations with zero downtime.	apexbyte-migration	\N	0	0	\N	bestseller	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Buy Now", "name": "Standard", "price": 199.0, "period": "user", "popular": false, "features": ["10 Mailboxes", "Standard Support"], "mailboxes": null, "originalPrice": null}, {"cta": "Contact Sales", "name": "Enterprise", "price": 499.0, "period": "user", "popular": true, "features": ["Unlimited Mailboxes", "Priority Support"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	[{"id": "r1", "date": "2025-01-10", "role": "IT Director", "author": "John Doe", "rating": 5, "company": "TechCorp", "content": "Migrated 500 users over the weekend without a hitch. Incredible tool."}]	\N	apexbyte	t	\N	\N	\N	\N	{}	\N	\N	\N
apexbyte-cloud-backup-pro	apexbyte-cloud-backup-pro	ApexByte Cloud Backup Pro	Automated, encrypted backups for AWS, Azure, and Google Cloud.	Ensure business continuity with point-in-time recovery for your cloud infrastructure.	apexbyte-backup	\N	0	0	\N	popular	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Get Started", "name": "Business", "price": 299.0, "period": "server", "popular": false, "features": ["Daily Backups", "AES-256 Encryption"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	[{"id": "r2", "date": "2025-02-15", "role": "DevOps Lead", "author": "Sarah Smith", "rating": 5, "company": "CloudNative Inc.", "content": "Saved us from a major data loss incident last month. Worth every penny."}]	\N	apexbyte	t	\N	\N	\N	\N	{}	\N	\N	\N
apexbyte-pdf-converter	apexbyte-pdf-converter	ApexByte PDF to Word Converter	High-fidelity document conversion retaining exact formatting.	Convert massive batches of PDF files into editable Word documents instantly.	apexbyte-converters	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Buy License", "name": "Personal", "price": 49.0, "period": "license", "popular": false, "features": ["Unlimited Conversions", "Basic Support"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	[{"id": "r3", "date": "2025-03-01", "role": "Legal Associate", "author": "Michael Chang", "rating": 4, "company": "Law Firm LLP", "content": "Handles complex legal formatting much better than Adobe."}]	\N	apexbyte	t	\N	\N	\N	\N	{}	\N	\N	\N
apexbyte-sql-migrator	apexbyte-sql-migrator	ApexByte SQL Schema Migrator	Translate schemas and move data between major relational databases.	Supports Oracle, SQL Server, MySQL, and PostgreSQL with automated schema translation.	apexbyte-database	\N	0	0	\N	new	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Request Demo", "name": "Professional", "price": 899.0, "period": "license", "popular": true, "features": ["Cross-database support", "Schema Mapping AI"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	[{"id": "r4", "date": "2025-04-12", "role": "DBA", "author": "Elena Rodriguez", "rating": 5, "company": "FinTech Solutions", "content": "The automated type mapping saved us weeks of manual work."}]	\N	apexbyte	t	\N	\N	\N	\N	{}	\N	\N	\N
apexbyte-duplicate-remover	apexbyte-duplicate-remover	ApexByte Outlook Duplicate Remover	Clean up cluttered Outlook mailboxes with smart algorithms.	Identifies and removes exact and partial duplicate emails, contacts, and calendar events.	apexbyte-migration	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Buy Now", "name": "Standard", "price": 29.0, "period": "license", "popular": false, "features": ["Email Cleanup", "Contact Merging"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	[{"id": "r5", "date": "2025-05-20", "role": "Executive Assistant", "author": "David Kim", "rating": 5, "company": "Global Corp", "content": "Freed up 10GB in my boss's mailbox in just 5 minutes."}]	\N	apexbyte	t	\N	\N	\N	\N	{}	\N	\N	\N
apexbyte-gws-backup	apexbyte-gws-backup	ApexByte Google Workspace Backup	Comprehensive backup for Gmail, Drive, Docs, and Sites.	Protect your entire Google Workspace environment against ransomware and accidental deletion.	apexbyte-backup	\N	0	0	\N	popular	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Contact Sales", "name": "Enterprise", "price": 399.0, "period": "domain", "popular": true, "features": ["Unlimited Users", "1-Click Restore"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	[{"id": "r6", "date": "2025-06-10", "role": "IT Manager", "author": "Lisa Wong", "rating": 5, "company": "EduTech", "content": "Restoring a deleted user's drive took less than a minute."}]	\N	apexbyte	t	\N	\N	\N	\N	{}	\N	\N	\N
brandD-p1	brandD-backup-suite	Brand D Backup Suite	Encrypted cloud and local backup solution to secure your corporate data bytes.	The ultimate security backups utility by Brand D	brandD-cat	\N	4.7	0	25K+	\N	1.0.0	2026-03-01	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	brandD	t	\N	\N	\N	\N	{}	\N	\N	\N
brandE-p1	brandE-pdf-converter	Brand E PDF Converter	Fastest binary document converter to translate PDF files to Excel, Word, and text.	The ultimate file converters utility by Brand E	brandE-cat	\N	4.7	0	25K+	\N	1.0.0	2026-03-01	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	brandE	t	\N	\N	\N	\N	{}	\N	\N	\N
uncle-pst-to-gmail	pst-to-gmail-converter	PST to Gmail Converter	The easiest way to move your old Outlook data to your Google account.	Don't let your old emails collect dust. Uncle's tool helps you seamlessly transfer all your Outlook PST files to your new Gmail account with just a few clicks. It's safe, secure, and incredibly friendly to use.	mgu-migration	\N	0	0	\N	bestseller	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Get It Now", "name": "Home User", "price": 29.0, "period": "user", "popular": false, "features": ["Up to 5 accounts", "Friendly Email Support"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	[{"id": "r1", "date": "2025-01-10", "role": "Retired Teacher", "author": "Mary P.", "rating": 5, "company": "Home User", "content": "I was so worried about losing my emails, but this tool was a breeze to use!"}]	\N	migrationuncle	t	\N	\N	\N	\N	{}	\N	\N	\N
uncle-ost-recovery	ost-recovery-tool	OST Recovery Tool	Rescue your data from corrupted Outlook offline files.	Got an OST file you can't open? Don't panic. Uncle's recovery kit will repair the file and extract your emails, contacts, and calendars so you can get back to work.	mgu-utility	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Buy License", "name": "Standard", "price": 49.0, "period": "license", "popular": false, "features": ["Unlimited Recoveries", "Priority Support"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	\N	\N	migrationuncle	t	\N	\N	\N	\N	{}	\N	\N	\N
uncle-duplicate-cleaner	duplicate-cleaner	Duplicate Cleaner	Tidy up your messy mailbox by finding and removing duplicate emails.	Is your inbox full of the same message? Uncle's Duplicate Cleaner scans your accounts and safely removes identical copies, giving you your space back.	mgu-utility	\N	0	0	\N	new	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Clean Inbox", "name": "Standard", "price": 25.0, "period": "license", "popular": true, "features": ["Safe Mode Review", "Works with Outlook & IMAP"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	[{"id": "r4", "date": "2025-04-12", "role": "Small Business Owner", "author": "Bob Jenkins", "rating": 5, "company": "Bob's Plumbing", "content": "Finally got rid of 3,000 duplicate emails that were driving me crazy."}]	\N	migrationuncle	t	\N	\N	\N	\N	{}	\N	\N	\N
uncle-cloud-migration-kit	cloud-migration-kit	Cloud Migration Kit	Move all your local files and emails to the cloud safely.	Moving to the cloud doesn't have to be scary. This kit handles everything from local archives to cloud mailboxes in one smooth process.	mgu-migration	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Go to Cloud", "name": "Pro", "price": 99.0, "period": "license", "popular": false, "features": ["Unlimited Data", "24/7 Phone Support"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	\N	\N	migrationuncle	t	\N	\N	\N	\N	{}	\N	\N	\N
uncle-mbox-to-pst	mbox-to-pst-converter	MBOX to PST Converter	Convert Apple Mail and Thunderbird files to Outlook.	Switching from Mac to PC? Or Thunderbird to Outlook? This tool converts your MBOX files to PST format flawlessly.	mgu-converter	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Buy Now", "name": "Basic", "price": 39.0, "period": "license", "popular": false, "features": ["Fast Conversion", "No Size Limits"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	\N	\N	migrationuncle	t	\N	\N	\N	\N	{}	\N	\N	\N
uncle-email-backup-pro	email-backup-pro	Email Backup Pro	Automated, secure backups for your IMAP or Exchange mailboxes.	Never lose an email again. Set it and forget it. Email Backup Pro takes daily snapshots of your mailboxes to local storage.	mgu-backup	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Subscribe", "name": "Annual", "price": 49.0, "period": "subscription", "popular": false, "features": ["Daily Backups", "AES-256 Encryption"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	\N	\N	migrationuncle	t	\N	\N	\N	\N	{}	\N	\N	\N
uncle-eml-viewer	eml-viewer-free	EML Viewer (Free)	A simple utility to view standalone .eml files.	Someone sent you an EML file and you don't have an email client installed? Use our free viewer to read the email and extract attachments.	mgu-utility	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Download Free", "name": "Free", "price": 0.0, "period": "free", "popular": false, "features": ["View EMLs", "Extract Attachments"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	\N	\N	migrationuncle	t	\N	\N	\N	\N	{}	\N	\N	\N
uncle-ost-to-pst	ost-to-pst-converter	OST to PST Converter	Convert healthy OST files to portable PST format.	Need to backup your Exchange cache or move it to another machine? Convert it to PST easily with this tool.	mgu-converter	\N	0	0	\N	\N	\N	\N	\N	\N	\N	\N	\N	[{"cta": "Buy Now", "name": "Standard", "price": 39.0, "period": "license", "popular": false, "features": ["Batch Conversion", "High Speed"], "mailboxes": null, "originalPrice": null}]	\N	\N	\N	\N	\N	migrationuncle	t	\N	\N	\N	\N	{}	\N	\N	\N
PRM-MIG-2026-002	prism-mbox-converter	MBOX to PST Converter	Extract mailboxes from Thunderbird, Apple Mail, and MBOX files to Outlook PST format with 100% data integrity.	<p>Prism MBOX to PST Converter is an enterprise-grade utility that extracts mailboxes from MBOX files and converts them into Microsoft Outlook PST files. Perfect for migrating from Thunderbird, Apple Mail, or Eudora to Outlook.</p><h3>Key Advantages:</h3><ul><li>Preserves folder hierarchical structures.</li><li>Extracts large attachments safely.</li><li>Supports batch file processing.</li></ul>	file-converter	["thunderbird", "mbox", "outlook"]	4.8	1420	15,200	popular	1.2.0	July 2026	\N	["Hierarchical Folder Retention", "Batch Conversion Mode", "Large Attachment Extraction"]	["Windows", "macOS"]	\N	\N	[{"name": "Personal License", "price": 29.0, "period": "lifetime", "popular": true, "features": ["Single user", "Extract attachments", "1-year updates"]}, {"name": "Enterprise License", "price": 99.0, "period": "lifetime", "popular": false, "features": ["Unlimited users", "Command line support", "Priority support"]}]	\N	\N	\N	\N	\N	brandA	t	["PRM-MIG-2026-001", "PRM-MIG-2026-003"]	\N	["mbox"]	["pst", "eml", "msg", "pdf", "html"]	{"supportsMultipleFiles": true, "supportsIncrementalSync": true}	\N	\N	https://downloads.datamigratepro.com/installers/prism-mbox-converter-trial.exe
PRM-MIG-2026-001	pst-converter	PST Convertor	it converts the file format in to the various diffrent diffrent file formats and email clients	<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>PST Converter - Convert Outlook PST Files Easily</title>\n    <style>\n        body {\n            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n            margin: 0;\n            padding: 0;\n            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);\n            color: #333;\n            line-height: 1.6;\n        }\n        .container {\n            max-width: 1100px;\n            margin: 0 auto;\n            padding: 40px 20px;\n        }\n        header {\n            text-align: center;\n            margin-bottom: 50px;\n        }\n        .logo {\n            font-size: 48px;\n            font-weight: bold;\n            color: #0078d4;\n            margin-bottom: 10px;\n        }\n        h1 {\n            color: #1e3a8a;\n            font-size: 2.8rem;\n            margin: 15px 0;\n        }\n        .subtitle {\n            font-size: 1.3rem;\n            color: #555;\n            max-width: 700px;\n            margin: 0 auto;\n        }\n        .features {\n            display: grid;\n            grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));\n            gap: 25px;\n            margin: 60px 0;\n        }\n        .card {\n            background: white;\n            border-radius: 12px;\n            padding: 30px;\n            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);\n            transition: transform 0.3s ease;\n        }\n        .card:hover {\n            transform: translateY(-8px);\n        }\n        .card h3 {\n            color: #0078d4;\n            margin-top: 0;\n        }\n        .benefits {\n            background: white;\n            border-radius: 12px;\n            padding: 40px;\n            margin: 60px 0;\n            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);\n        }\n        .cta {\n            text-align: center;\n            margin: 50px 0;\n        }\n        .btn {\n            display: inline-block;\n            background: #0078d4;\n            color: white;\n            padding: 16px 40px;\n            font-size: 1.2rem;\n            border-radius: 50px;\n            text-decoration: none;\n            font-weight: 600;\n            box-shadow: 0 8px 25px rgba(0, 120, 212, 0.3);\n            transition: all 0.3s;\n        }\n        .btn:hover {\n            background: #005eb8;\n            transform: scale(1.05);\n        }\n        footer {\n            text-align: center;\n            padding: 30px;\n            color: #666;\n            font-size: 0.95rem;\n        }\n    </style>\n</head>\n<body>\n    <div class="container">\n        <header>\n            <div class="logo">📧 PST Converter</div>\n            <h1>Convert Outlook PST Files with Ease</h1>\n            <p class="subtitle">\n                Fast, secure, and reliable PST to EML, MSG, MBOX, PDF, HTML, and other formats conversion tool.\n            </p>\n        </header>\n\n        <div class="features">\n            <div class="card">\n                <h3>🔄 Multiple Formats</h3>\n                <p>Convert PST files to EML, MSG, MBOX, PDF, HTML, CSV, vCard, and many more formats without losing any data.</p>\n            </div>\n            <div class="card">\n                <h3>📁 Bulk Conversion</h3>\n                <p>Process entire folders or multiple PST files at once. Perfect for migrating large email archives.</p>\n            </div>\n            <div class="card">\n                <h3>🔐 Data Integrity</h3>\n                <p>Preserves email structure, attachments, formatting, metadata, and folder hierarchy during conversion.</p>\n            </div>\n        </div>\n\n        <div class="benefits">\n            <h2 style="text-align:center; color:#1e3a8a;">Why Choose Our PST Converter?</h2>\n            <ul style="max-width:800px; margin:30px auto; font-size:1.1rem;">\n                <li>✅ Supports password-protected PST files</li>\n                <li>✅ No data loss - 100% accurate conversion</li>\n                <li>✅ Works with ANSI, Unicode, and Outlook 2019/2021/365 PSTs</li>\n                <li>✅ Preview emails before conversion</li>\n                <li>✅ Batch processing and selective folder conversion</li>\n                <li>✅ Lightweight and user-friendly interface</li>\n            </ul>\n        </div>\n\n        <div class="cta">\n            <a href="#" class="btn">Download PST Converter Now</a>\n            <p style="margin-top:20px; color:#555;">Free trial available • No credit card required</p>\n        </div>\n    </div>\n\n    <footer>\n        <p><strong>PST Converter</strong> — Effortlessly migrate and backup your Outlook emails</p>\n    </footer>\n</body>\n</html>	email-migration	["outlook"]	0	0	\N	popular	1.0.0	\N	/download/trial?product=pst-converter	[]	["Windows"]	[]	\N	[{"cta": "", "name": "Standard License", "price": 49.0, "period": "lifetime", "popular": false, "features": ["1 Mailbox migration", "Free 1-year updates", "24/7 technical support"], "mailboxes": null, "originalPrice": null}, {"cta": "", "name": "New Tier", "price": 59.0, "period": "lifetime", "popular": false, "features": ["1 PC License", "Free lifetime support"], "mailboxes": null, "originalPrice": 99.0}, {"cta": "", "name": "New Tier", "price": 59.0, "period": "lifetime", "popular": false, "features": ["1 PC License", "Free lifetime support"], "mailboxes": null, "originalPrice": 99.0}]	{"title": "", "ogImage": null, "ogTitle": null, "keywords": [], "description": "", "canonicalUrl": null, "ogDescription": null}	{"os": "Windows 11/10/8/7 (32/64 bit)", "ram": "2 GB", "disk": "100 MB", "macOs": null, "other": null, "macRam": null, "linuxOs": null, "macDisk": null, "linuxRam": null, "linuxDisk": null, "processor": "1 GHz Intel/AMD processor", "macProcessor": null, "linuxProcessor": null}	[{"icon": "arrow-right", "step": 1, "title": "Download & Install", "description": "Download the software and install it on your PC."}, {"icon": "arrow-right", "step": 2, "title": "Add PST File", "description": "Launch the software and select the Outlook PST file you want to convert."}, {"icon": "arrow-right", "step": 3, "title": "Select Output", "description": "Choose the output format and destination path."}, {"icon": "arrow-right", "step": 4, "title": "Convert & Export", "description": "Click Convert to export your mailbox items."}]	[{"id": "rev-1", "date": "2026-07-10", "role": "System Administrator", "author": "John D.", "rating": 5, "company": "Tech Solutions", "content": "Excellent converter, saved me hours of work!"}]	[{"answer": "Yes, our software has no file size limit and can convert large PST files without data loss.", "question": "Can I converdfsadft large PST files?"}]	brandA	t	["PRM-MIG-2026-002", "PRM-MIG-2026-003"]	\N	["pst"]	["mbox", "eml", "pdf", "gmail", "office365", "html"]	{"extractEmails": true, "extractContacts": true, "extractCalendars": true, "supportsMultipleFiles": true, "supportsIncrementalSync": true}	/thank-you-install?product=pst-converter	/goodbye?product=pst-converter	https://downloads.datamigratepro.com/installers/pst-converter-trial.exe
PRM-MIG-2026-003	prism-email-backup	Email Backup Pro	Securely download and archive cloud mailboxes (Gmail, Office 365, IMAP) to local archives.	<p>Ensure business continuity by archiving cloud mailboxes locally. Email Backup Pro connects securely via OAuth or IMAP to download all mail, folders, contacts, and calendars into safe offline storage files.</p><h3>Key Advantages:</h3><ul><li>Automatic scheduled backup runs.</li><li>Supports major cloud providers (Gmail, Office 365).</li><li>Encrypted storage options.</li></ul>	backup-tools	["backup", "gmail", "office365"]	4.9	2840	32,400	bestseller	2.1.4	June 2026	\N	["Secure OAuth Authentication", "Incremental Backup Mode", "Auto-Backup Scheduler"]	["Windows", "macOS"]	\N	\N	[{"name": "Personal Annual", "price": 39.0, "period": "yearly", "popular": false, "features": ["1 Cloud account", "Scheduled backups", "Standard support"]}, {"name": "Business Lifetime", "price": 149.0, "period": "lifetime", "popular": true, "features": ["Unlimited accounts", "Priority support", "Zero recurring fees"]}]	\N	\N	\N	\N	\N	brandA	t	["PRM-MIG-2026-001", "PRM-MIG-2026-002"]	\N	["gmail", "office365", "imap"]	["pst", "mbox", "eml", "pdf"]	{"supportsMultipleFiles": true, "supportsMultipleAccounts": true}	\N	\N	https://downloads.datamigratepro.com/installers/prism-email-backup-trial.exe
PRM-MIG-2026-004	share-point-migration	Share point Migration			email-migration	["outlook"]	0	0	\N	new	1.0.0	\N	/download/trial?product=share-point-migration	[]	["Windows", "macOS"]	[]	\N	[{"cta": "", "name": "Standard License", "price": 49.0, "period": "lifetime", "popular": false, "features": ["1 Mailbox migration", "Free 1-year updates", "24/7 technical support"], "mailboxes": null, "originalPrice": null}, {"cta": "", "name": "New Tier", "price": 59.0, "period": "lifetime", "popular": false, "features": ["1 PC License", "Free lifetime support"], "mailboxes": null, "originalPrice": 99.0}, {"cta": "", "name": "New Tier", "price": 59.0, "period": "lifetime", "popular": false, "features": ["1 PC License", "Free lifetime support"], "mailboxes": null, "originalPrice": 99.0}, {"cta": "", "name": "New Tier", "price": 59.0, "period": "lifetime", "popular": false, "features": ["1 PC License", "Free lifetime support"], "mailboxes": null, "originalPrice": 99.0}]	{"title": "", "ogImage": null, "ogTitle": null, "keywords": [], "description": "", "canonicalUrl": null, "ogDescription": null}	{"os": "Windows 11/10/8/7 (32/64 bit)", "ram": "2 GB", "disk": "100 MB", "other": null, "processor": "1 GHz Intel/AMD processor"}	[{"icon": "arrow-right", "step": 1, "title": "Download & Install", "description": "Download the software and install it on your PC."}, {"icon": "arrow-right", "step": 2, "title": "Add PST File", "description": "Launch the software and select the Outlook PST file you want to convert."}, {"icon": "arrow-right", "step": 3, "title": "Select Output", "description": "Choose the output format and destination path."}, {"icon": "arrow-right", "step": 4, "title": "Convert & Export", "description": "Click Convert to export your mailbox items."}]	[{"id": "rev-1", "date": "2026-07-12", "role": "System Administrator", "author": "John D.", "rating": 5, "company": "Tech Solutions", "content": "Excellent converter, saved me hours of work!"}]	[{"answer": "Yes, our software has no file size limit and can convert large PST files without data loss.", "question": "Can I convert large PST files?"}]	brandA	t	[]	\N	["site-migration"]	["pst", "mbox", "eml", "pdf", "gmail", "site-migration", "html", "office365"]	{"supportsImpersonation": true, "supportsIncrementalSync": true, "supportsMultipleAccounts": true}	/thank-you-install?product=share-point-migration	/goodbye?product=share-point-migration	https://downloads.datamigratepro.com/installers/share-point-migration-trial.exe
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.site_settings (id, site_id, name, tagline, description, url, email, phone, address, socials, stats, trust_badges, team_members, pricing_comparison, pricing_faqs, theme, main_navigation, footer_config, hero, home_sections, legal_pages, about_page, coupons, announcement, seo_defaults, careers_page, clients_page, review_platform_name, review_platform_url, review_platform_rating, review_platform_count, live_chat_embed_code, press_mentions) FROM stdin;
settings-apexbyte	apexbyte	ApexByte Soft	Precision Software for Modern IT Teams	Enterprise-grade migration, conversion, and data management tools built for speed, security, and scalability.	https://apexbyte.local	support@apexbyte.local	+1 (800) 123-4567	ApexByte HQ	{"github": "https://github.com/apexbyte", "twitter": "https://twitter.com/apexbyte", "youtube": "https://youtube.com/@apexbyte", "facebook": "https://facebook.com/apexbyte", "linkedin": "https://linkedin.com/company/apexbyte"}	[{"label": "Downloads", "value": "500K+"}, {"label": "Happy Users", "value": "10K+"}, {"label": "Avg Rating", "value": "4.8★"}, {"label": "Success Rate", "value": "99.9%"}]	[{"desc": "256-bit SSL encryption.", "color": "text-green-600 bg-green-50", "emoji": "🛡️", "title": "Secure & Safe"}]	\N	\N	\N	\N	[{"href": "#", "icon": null, "label": "Products", "enabled": true, "children": [{"href": "/products?category=email-migration", "icon": null, "label": "Email Migration", "enabled": true, "children": null}, {"href": "/products?category=file-converters", "icon": null, "label": "File Converters", "enabled": true, "children": null}]}, {"href": "/pricing", "icon": null, "label": "Pricing", "enabled": true, "children": null}, {"href": "/careers", "icon": null, "label": "Careers", "enabled": true, "children": null}, {"href": "/contact", "icon": null, "label": "Contact", "enabled": true, "children": null}]	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
settings-brandD	brandD	Brand D	Secure Server Backups & Cloud Sync Operations	Official storefront for Brand D. Advanced solutions for secure server backups & cloud sync operations.	https://brandD.com	support@brandD.com	+1 (800) 555-0103	456 Suite St, Silicon Valley, CA 94025	{"github": "https://github.com/brandD", "twitter": "https://twitter.com/brandD", "youtube": "https://youtube.com/@brandD", "facebook": "https://facebook.com/brandD", "linkedin": "https://linkedin.com/company/brandD"}	[{"label": "Downloads", "value": "200K+"}, {"label": "Happy Users", "value": "15K+"}, {"label": "Avg Rating", "value": "4.8★"}, {"label": "Success Rate", "value": "99.5%"}]	[{"desc": "256-bit SSL encryption.", "color": "text-green-600 bg-green-50", "emoji": "🛡️", "title": "Secure & Safe"}, {"desc": "No data collection. Local processing only.", "color": "text-blue-600 bg-blue-50", "emoji": "🔒", "title": "Privacy First"}, {"desc": "Not satisfied? Full refund within 30 days.", "color": "text-amber-600 bg-amber-50", "emoji": "⏱️", "title": "30-Day Guarantee"}, {"desc": "Expert support team available around the clock.", "color": "text-purple-600 bg-purple-50", "emoji": "🎧", "title": "24/7 Support"}, {"desc": "Get all future updates included.", "color": "text-cyan-600 bg-cyan-50", "emoji": "🔄", "title": "Free Updates"}, {"desc": "Recognized by top industry publications.", "color": "text-red-600 bg-red-50", "emoji": "🏆", "title": "Award Winning"}]	[{"bio": "15+ years in enterprise data migration. Former Microsoft engineer.", "name": "Michael Ross", "role": "CEO & Co-Founder", "initials": "MR"}, {"bio": "Expert in distributed systems and data integrity algorithms.", "name": "Jessica Chen", "role": "CTO & Co-Founder", "initials": "JC"}, {"bio": "Passionate about building tools that solve real IT problems.", "name": "David Kumar", "role": "Head of Product", "initials": "DK"}, {"bio": "Dedicated to ensuring every customer succeeds with our tools.", "name": "Sarah Williams", "role": "Head of Support", "initials": "SW"}]	[{"trial": "50 emails", "feature": "Email Migration", "standard": "Unlimited", "enterprise": "Unlimited"}, {"trial": "Yes", "feature": "Contacts & Calendar", "standard": "Yes", "enterprise": "Yes"}, {"trial": "Yes", "feature": "Folder Structure", "standard": "Yes", "enterprise": "Yes"}, {"trial": "No", "feature": "Batch Migration", "standard": "No", "enterprise": "Yes"}, {"trial": "No", "feature": "Delta Migration", "standard": "Yes", "enterprise": "Yes"}, {"trial": "1", "feature": "Number of Licenses", "standard": "1", "enterprise": "25"}, {"trial": "No", "feature": "Free Updates", "standard": "1 Year", "enterprise": "Lifetime"}, {"trial": "Email", "feature": "Technical Support", "standard": "Priority Email", "enterprise": "24/7 Phone & Chat"}, {"trial": "Free", "feature": "Price", "standard": "$49", "enterprise": "$199"}]	[{"answer": "No. All our tools use a one-time payment model. Pay once, use forever.", "question": "Do I need a subscription?"}, {"answer": "Yes! Every product has a free trial that lets you migrate/convert up to 50 items.", "question": "Is there a free trial?"}, {"answer": "We offer a 30-day money-back guarantee. No questions asked.", "question": "What if I'm not satisfied?"}, {"answer": "Standard plans include 1 year of free updates. Enterprise/Business plans include lifetime updates.", "question": "Do I get free updates?"}]	\N	\N	\N	\N	\N	{"terms": "<h2>Terms of Service</h2><p>Welcome to Brand D. By accessing <a href=\\"https://brandD.com\\">https://brandD.com</a> or downloading our software products, you agree to comply with and be bound by the following terms and conditions of use.</p><h3>1. License to Use</h3><p>We grant you a non-exclusive, non-transferable, and revocable license to use our data tools in accordance with the purchased tier specifications (Standard, Business, or Enterprise).</p><h3>2. Restrictions</h3><p>You are explicitly prohibited from reverse engineering, redistributing, leasing, or sharing single-machine activation keys with unauthorized third parties. Violations will result in immediate license termination without a refund.</p><h3>3. Limitation of Liability</h3><p>In no event shall Brand D be held liable for any data loss, system downtime, or commercial damages arising from the use or inability to use our software products.</p>", "refund": "<h2>Refund Policy</h2><p>We value customer satisfaction and stand behind our products. We offer a <strong>30-day money-back guarantee</strong> on all software purchases to ensure our customers find the software suitable for their needs.</p><h3>1. Guarantee Conditions</h3><p>If our software is unable to perform as advertised, and our support team cannot resolve the technical problem, you are eligible to request a full refund within 30 days of the purchase transaction date.</p><h3>2. How to Request a Refund</h3><p>Please send an email to support@brandD.com including your original order receipt, transaction ID, license key details, and a brief description of the technical issue you encountered.</p><h3>3. License Deactivation</h3><p>Upon approval and processing of the refund, all associated product license keys and active machine activations will be immediately deactivated and blacklisted from our licensing validation server.</p>", "license": "<h2>License Agreement (EULA)</h2><p>This End User License Agreement (EULA) is a binding legal agreement between you (an individual or entity) and Brand D for the software product accompanying this agreement.</p><h3>1. License Grant</h3><p>Brand D grants you a personal, non-transferable, non-exclusive license to install and run the software on the number of devices specified in your purchase order (e.g., 1 computer for Standard, up to 25 for Enterprise).</p><h3>2. Intellectual Property Rights</h3><p>The software, its code, structure, design, and assets are the exclusive intellectual property of Brand D and are protected by international copyright laws. No title or property rights are transferred to you.</p><h3>3. Termination</h3><p>This agreement terminates automatically if you fail to comply with any of its terms. Upon termination, you must cease all use of the software and permanently uninstall it from all devices.</p>", "privacy": "<h2>Privacy Policy</h2><p>At Brand D, accessible from <a href=\\"https://brandD.com\\">https://brandD.com</a>, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Brand D and how we use it.</p><h3>1. Information We Collect</h3><p>We collect information directly from you when you register, buy software licenses, or contact our support team. This may include your name, email address, transaction history, and machine-identifying IP details to authenticate and manage your product license keys.</p><h3>2. How We Use Your Information</h3><p>We use the collected data to verify active product licensing, prevent fraudulent license redistribution, distribute software updates, and deliver responsive support services at support@brandD.com.</p><h3>3. Data Protection & Security</h3><p>All payment operations are handled securely by PCI-DSS compliant third-party payment gateways. We do not store credit card details. License checking is executed locally on client machines using secure 256-bit SSL connections.</p>"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
settings-brandE	brandE	Brand E	Binary File Converters & Document Translators	Official storefront for Brand E. Advanced solutions for binary file converters & document translators.	https://brandE.com	support@brandE.com	+1 (800) 555-0104	456 Suite St, Silicon Valley, CA 94025	{"github": "https://github.com/brandE", "twitter": "https://twitter.com/brandE", "youtube": "https://youtube.com/@brandE", "facebook": "https://facebook.com/brandE", "linkedin": "https://linkedin.com/company/brandE"}	[{"label": "Downloads", "value": "200K+"}, {"label": "Happy Users", "value": "15K+"}, {"label": "Avg Rating", "value": "4.8★"}, {"label": "Success Rate", "value": "99.5%"}]	[{"desc": "256-bit SSL encryption.", "color": "text-green-600 bg-green-50", "emoji": "🛡️", "title": "Secure & Safe"}, {"desc": "No data collection. Local processing only.", "color": "text-blue-600 bg-blue-50", "emoji": "🔒", "title": "Privacy First"}, {"desc": "Not satisfied? Full refund within 30 days.", "color": "text-amber-600 bg-amber-50", "emoji": "⏱️", "title": "30-Day Guarantee"}, {"desc": "Expert support team available around the clock.", "color": "text-purple-600 bg-purple-50", "emoji": "🎧", "title": "24/7 Support"}, {"desc": "Get all future updates included.", "color": "text-cyan-600 bg-cyan-50", "emoji": "🔄", "title": "Free Updates"}, {"desc": "Recognized by top industry publications.", "color": "text-red-600 bg-red-50", "emoji": "🏆", "title": "Award Winning"}]	[{"bio": "15+ years in enterprise data migration. Former Microsoft engineer.", "name": "Michael Ross", "role": "CEO & Co-Founder", "initials": "MR"}, {"bio": "Expert in distributed systems and data integrity algorithms.", "name": "Jessica Chen", "role": "CTO & Co-Founder", "initials": "JC"}, {"bio": "Passionate about building tools that solve real IT problems.", "name": "David Kumar", "role": "Head of Product", "initials": "DK"}, {"bio": "Dedicated to ensuring every customer succeeds with our tools.", "name": "Sarah Williams", "role": "Head of Support", "initials": "SW"}]	[{"trial": "50 emails", "feature": "Email Migration", "standard": "Unlimited", "enterprise": "Unlimited"}, {"trial": "Yes", "feature": "Contacts & Calendar", "standard": "Yes", "enterprise": "Yes"}, {"trial": "Yes", "feature": "Folder Structure", "standard": "Yes", "enterprise": "Yes"}, {"trial": "No", "feature": "Batch Migration", "standard": "No", "enterprise": "Yes"}, {"trial": "No", "feature": "Delta Migration", "standard": "Yes", "enterprise": "Yes"}, {"trial": "1", "feature": "Number of Licenses", "standard": "1", "enterprise": "25"}, {"trial": "No", "feature": "Free Updates", "standard": "1 Year", "enterprise": "Lifetime"}, {"trial": "Email", "feature": "Technical Support", "standard": "Priority Email", "enterprise": "24/7 Phone & Chat"}, {"trial": "Free", "feature": "Price", "standard": "$49", "enterprise": "$199"}]	[{"answer": "No. All our tools use a one-time payment model. Pay once, use forever.", "question": "Do I need a subscription?"}, {"answer": "Yes! Every product has a free trial that lets you migrate/convert up to 50 items.", "question": "Is there a free trial?"}, {"answer": "We offer a 30-day money-back guarantee. No questions asked.", "question": "What if I'm not satisfied?"}, {"answer": "Standard plans include 1 year of free updates. Enterprise/Business plans include lifetime updates.", "question": "Do I get free updates?"}]	\N	\N	\N	\N	\N	{"terms": "<h2>Terms of Service</h2><p>Welcome to Brand E. By accessing <a href=\\"https://brandE.com\\">https://brandE.com</a> or downloading our software products, you agree to comply with and be bound by the following terms and conditions of use.</p><h3>1. License to Use</h3><p>We grant you a non-exclusive, non-transferable, and revocable license to use our data tools in accordance with the purchased tier specifications (Standard, Business, or Enterprise).</p><h3>2. Restrictions</h3><p>You are explicitly prohibited from reverse engineering, redistributing, leasing, or sharing single-machine activation keys with unauthorized third parties. Violations will result in immediate license termination without a refund.</p><h3>3. Limitation of Liability</h3><p>In no event shall Brand E be held liable for any data loss, system downtime, or commercial damages arising from the use or inability to use our software products.</p>", "refund": "<h2>Refund Policy</h2><p>We value customer satisfaction and stand behind our products. We offer a <strong>30-day money-back guarantee</strong> on all software purchases to ensure our customers find the software suitable for their needs.</p><h3>1. Guarantee Conditions</h3><p>If our software is unable to perform as advertised, and our support team cannot resolve the technical problem, you are eligible to request a full refund within 30 days of the purchase transaction date.</p><h3>2. How to Request a Refund</h3><p>Please send an email to support@brandE.com including your original order receipt, transaction ID, license key details, and a brief description of the technical issue you encountered.</p><h3>3. License Deactivation</h3><p>Upon approval and processing of the refund, all associated product license keys and active machine activations will be immediately deactivated and blacklisted from our licensing validation server.</p>", "license": "<h2>License Agreement (EULA)</h2><p>This End User License Agreement (EULA) is a binding legal agreement between you (an individual or entity) and Brand E for the software product accompanying this agreement.</p><h3>1. License Grant</h3><p>Brand E grants you a personal, non-transferable, non-exclusive license to install and run the software on the number of devices specified in your purchase order (e.g., 1 computer for Standard, up to 25 for Enterprise).</p><h3>2. Intellectual Property Rights</h3><p>The software, its code, structure, design, and assets are the exclusive intellectual property of Brand E and are protected by international copyright laws. No title or property rights are transferred to you.</p><h3>3. Termination</h3><p>This agreement terminates automatically if you fail to comply with any of its terms. Upon termination, you must cease all use of the software and permanently uninstall it from all devices.</p>", "privacy": "<h2>Privacy Policy</h2><p>At Brand E, accessible from <a href=\\"https://brandE.com\\">https://brandE.com</a>, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Brand E and how we use it.</p><h3>1. Information We Collect</h3><p>We collect information directly from you when you register, buy software licenses, or contact our support team. This may include your name, email address, transaction history, and machine-identifying IP details to authenticate and manage your product license keys.</p><h3>2. How We Use Your Information</h3><p>We use the collected data to verify active product licensing, prevent fraudulent license redistribution, distribute software updates, and deliver responsive support services at support@brandE.com.</p><h3>3. Data Protection & Security</h3><p>All payment operations are handled securely by PCI-DSS compliant third-party payment gateways. We do not store credit card details. License checking is executed locally on client machines using secure 256-bit SSL connections.</p>"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
settings-migrationuncle	migrationuncle	Migration Uncle	Reliable & Friendly Data Migration Tools for Everyone.	We make migrating your emails, databases, and files as easy as asking your favorite uncle for help. Warm, trustworthy, and effective.	https://migrationuncle.com	hello@migrationuncle.com	+1 (800) 555-UNCLE	789 Oak Lane, Techville, CA 90210	{"github": "https://github.com/migrationuncle", "twitter": "https://twitter.com/migrationuncle", "youtube": "https://youtube.com/@migrationuncle", "facebook": "https://facebook.com/migrationuncle", "linkedin": "https://linkedin.com/company/migrationuncle"}	[{"label": "Downloads", "value": "500K+"}, {"label": "Happy Users", "value": "25K+"}, {"label": "Avg Rating", "value": "4.9★"}, {"label": "Success Rate", "value": "99.8%"}]	\N	\N	\N	\N	\N	[{"href": "/products", "icon": null, "label": "Products", "enabled": true, "children": null}, {"href": "/pricing", "icon": null, "label": "Pricing", "enabled": true, "children": null}, {"href": "/help", "icon": null, "label": "Help Center", "enabled": true, "children": null}, {"href": "/careers", "icon": null, "label": "Careers", "enabled": true, "children": null}, {"href": "/contact", "icon": null, "label": "Contact", "enabled": true, "children": null}]	\N	\N	\N	{"terms": "<h2>Terms of Service</h2><p>Welcome to Migration Uncle. By accessing <a href=\\"https://migrationuncle.com\\">https://migrationuncle.com</a> or downloading our software products, you agree to comply with and be bound by the following terms and conditions of use.</p><h3>1. License to Use</h3><p>We grant you a non-exclusive, non-transferable, and revocable license to use our data tools in accordance with the purchased tier specifications (Standard, Business, or Enterprise).</p><h3>2. Restrictions</h3><p>You are explicitly prohibited from reverse engineering, redistributing, leasing, or sharing single-machine activation keys with unauthorized third parties. Violations will result in immediate license termination without a refund.</p><h3>3. Limitation of Liability</h3><p>In no event shall Migration Uncle be held liable for any data loss, system downtime, or commercial damages arising from the use or inability to use our software products.</p>", "refund": "<h2>Refund Policy</h2><p>We value customer satisfaction and stand behind our products. We offer a <strong>30-day money-back guarantee</strong> on all software purchases to ensure our customers find the software suitable for their needs.</p><h3>1. Guarantee Conditions</h3><p>If our software is unable to perform as advertised, and our support team cannot resolve the technical problem, you are eligible to request a full refund within 30 days of the purchase transaction date.</p><h3>2. How to Request a Refund</h3><p>Please send an email to hello@migrationuncle.com including your original order receipt, transaction ID, license key details, and a brief description of the technical issue you encountered.</p><h3>3. License Deactivation</h3><p>Upon approval and processing of the refund, all associated product license keys and active machine activations will be immediately deactivated and blacklisted from our licensing validation server.</p>", "license": "<h2>License Agreement (EULA)</h2><p>This End User License Agreement (EULA) is a binding legal agreement between you (an individual or entity) and Migration Uncle for the software product accompanying this agreement.</p><h3>1. License Grant</h3><p>Migration Uncle grants you a personal, non-transferable, non-exclusive license to install and run the software on the number of devices specified in your purchase order (e.g., 1 computer for Standard, up to 25 for Enterprise).</p><h3>2. Intellectual Property Rights</h3><p>The software, its code, structure, design, and assets are the exclusive intellectual property of Migration Uncle and are protected by international copyright laws. No title or property rights are transferred to you.</p><h3>3. Termination</h3><p>This agreement terminates automatically if you fail to comply with any of its terms. Upon termination, you must cease all use of the software and permanently uninstall it from all devices.</p>", "privacy": "<h2>Privacy Policy</h2><p>At Migration Uncle, accessible from <a href=\\"https://migrationuncle.com\\">https://migrationuncle.com</a>, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Migration Uncle and how we use it.</p><h3>1. Information We Collect</h3><p>We collect information directly from you when you register, buy software licenses, or contact our support team. This may include your name, email address, transaction history, and machine-identifying IP details to authenticate and manage your product license keys.</p><h3>2. How We Use Your Information</h3><p>We use the collected data to verify active product licensing, prevent fraudulent license redistribution, distribute software updates, and deliver responsive support services at hello@migrationuncle.com.</p><h3>3. Data Protection & Security</h3><p>All payment operations are handled securely by PCI-DSS compliant third-party payment gateways. We do not store credit card details. License checking is executed locally on client machines using secure 256-bit SSL connections.</p>"}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
89371417-8fbe-4c29-870b-b03dbdb31179	brandA	Prism Migration	Enterprise Mailbox & Database MMigrators	Automated migration tools built to run locally.	https://brandA.thecrazyufo.in	hardevnagar@flasdf	8888888888	29/B Hardev Nagar, Karrahi, barra	{"github": "githibbfbadsfasdfads", "twitter": "twitteeeeer", "youtube": "youttnenrerewr", "facebook": "facecnoadsfadsq", "linkedin": "linkkekdeeed"}	\N	\N	\N	[]	[]	{"logoUrl": "", "darkMode": false, "faviconUrl": "", "fontFamily": "Roboto", "accentColor": "#8e713e", "navbarStyle": "solid", "primaryColor": "#0f2452"}	[{"href": "/products", "icon": "package", "label": "Products", "enabled": true, "children": null}, {"href": "/pricing", "icon": "dollar", "label": "Pricing", "enabled": true, "children": null}, {"href": "/download", "icon": "download", "label": "Download", "enabled": true, "children": null}, {"href": "/blog", "icon": "file-text", "label": "Blog", "enabled": true, "children": null}, {"href": "/help", "icon": "help-circle", "label": "Help", "enabled": true, "children": null}, {"href": "/about", "icon": "info", "label": "About", "enabled": true, "children": null}, {"href": "/contact", "icon": "mail", "label": "Contact", "enabled": true, "children": null}]	\N	{"headline": "Migrate Data at Lightning Speed Without Losing a Single Bytefdsfdsf", "badgeText": "Trusted by 50,000+ IT Professionals", "subheadline": "Eliminate downtime and secure your enterprise data. Our automated migration tools handle emails, files, and cloud transfers in seconds—saving you thousands in IT hours.", "ctaPrimaryHref": "/products", "ctaPrimaryText": "View Products", "ctaSecondaryHref": "/download", "ctaSecondaryText": "Free Trial"}	\N	{"terms": "<h2>Terms of Service</h2><p>Welcome to Prism Migration. By accessing <a href=\\"https://prismmigration.com\\">https://prismmigration.com</a> or downloading our software products, you agree to comply with and be bound by the following terms and conditions of use.</p><h3>1. License to Use</h3><p>We grant you a non-exclusive, non-transferable, and revocable license to use our data tools in accordance with the purchased tier specifications (Standard, Business, or Enterprise).</p><h3>2. Restrictions</h3><p>You are explicitly prohibited from reverse engineering, redistributing, leasing, or sharing single-machine activation keys with unauthorized third parties. Violations will result in immediate license termination without a refund.</p><h3>3. Limitation of Liability</h3><p>In no event shall Prism Migration be held liable for any data loss, system downtime, or commercial damages arising from the use or inability to use our software products.</p>", "refund": "<h2>Refund Policy</h2><p>We value customer satisfaction and stand behind our products. We offer a <strong>30-day money-back guarantee</strong> on all software purchases to ensure our customers find the software suitable for their needs.</p><h3>1. Guarantee Conditions</h3><p>If our software is unable to perform as advertised, and our support team cannot resolve the technical problem, you are eligible to request a full refund within 30 days of the purchase transaction date.</p><h3>2. How to Request a Refund</h3><p>Please send an email to support@prismmigration.com including your original order receipt, transaction ID, license key details, and a brief description of the technical issue you encountered.</p><h3>3. License Deactivation</h3><p>Upon approval and processing of the refund, all associated product license keys and active machine activations will be immediately deactivated and blacklisted from our licensing validation server.</p>", "license": "<h2>License Agreement (EULA)</h2><p>This End User License Agreement (EULA) is a binding legal agreement between you (an individual or entity) and Prism Migration for the software product accompanying this agreement.</p><h3>1. License Grant</h3><p>Prism Migration grants you a personal, non-transferable, non-exclusive license to install and run the software on the number of devices specified in your purchase order (e.g., 1 computer for Standard, up to 25 for Enterprise).</p><h3>2. Intellectual Property Rights</h3><p>The software, its code, structure, design, and assets are the exclusive intellectual property of Prism Migration and are protected by international copyright laws. No title or property rights are transferred to you.</p><h3>3. Termination</h3><p>This agreement terminates automatically if you fail to comply with any of its terms. Upon termination, you must cease all use of the software and permanently uninstall it from all devices.</p>", "privacy": "<h2>Privacy Policy</h2><p>At Prism Migration, accessible from <a href=\\"https://prismmigration.com\\">https://prismmigration.com</a>, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Prism Migration and how we use it.</p><h3>1. Information We Collect</h3><p>We collect information directly from you when you register, buy software licenses, or contact our support team. This may include your name, email address, transaction history, and machine-identifying IP details to authenticate and manage your product license keys.</p><h3>2. How We Use Your Information</h3><p>We use the collected data to verify active product licensing, prevent fraudulent license redistribution, distribute software updates, and deliver responsive support services at support@prismmigration.com.</p><h3>3. Data Protection & Security</h3><p>All payment operations are handled securely by PCI-DSS compliant third-party payment gateways. We do not store credit card details. License checking is executed locally on client machines using secure 256-bit SSL connections.</p>"}	{"showTeam": true, "heroTitle": "Trusted by IT Professionals Across the Globe ", "showStats": true, "missionTitle": "Data Migration Should Be Simple, Safe & Reliable", "missionContent": "<H1> </H1>", "heroDescription": "We build the world's most reliable data management software."}	\N	{"link": "/products", "text": "sale ahi9a bhai sale hai lelo", "bgColor": "#f2649d", "enabled": false, "textColor": "#ffffff"}	\N	{"benefits": [{"icon": "Globe", "title": "Remote First", "description": "Work from anywhere in the world."}, {"icon": "Heart", "title": "Health & Wellness", "description": "Comprehensive premium health coverage."}, {"icon": "BookOpen", "title": "Learning & Growth", "description": "Annual education budget for courses/books."}], "heroTitle": "Join Our Team", "metaTitle": "Careers at Prism Migration | Join Our Team", "metaKeywords": "careers, jobs, engineering jobs, remote jobs", "openPositions": [{"id": "job-1", "type": "Full-Time", "title": "Senior Full-Stack Engineer", "active": true, "location": "Remote, US/Europe", "department": "Engineering", "experience": "Senior (5+ years)", "description": "Looking for an engineer to lead feature development on our core selling platforms.", "salaryRange": "$130k - $160k", "requirements": "• 5+ years with React, Next.js, and Java/Spring Boot\\n• Experience with SQL and database design\\n• Strong product sense"}], "heroDescription": "Help us build the future of software selling and data migration.", "metaDescription": "Explore career opportunities at Prism Migration. We are looking for talented engineers, designers, and marketers.", "companyCultureDesc": "description culture sfadsfasdf sfsad fdsafjadsfjsadfads sdjfads fadsf dsf dssfs", "companyCultureTitle": "iltureasdfasdfadsf"}	{"stats": [{"label": "Companies Trust Us", "value": "150+"}, {"label": "Countries Served", "value": "50+"}, {"label": "Items Migrated", "value": "10B+"}, {"label": "Success Rate", "value": "99.9%"}], "ctaText": "Ready to migrate your database, mailboxes, or cloud storage? Start your risk-free trial today or contact our integration team.", "ctaTitle": "Join Our Growing List of Clients", "heroTitle": "Trusted by Leading Organizations", "metaTitle": "Our Clients — Enterprise Data Migration Success Stories", "heroSubtitle": "We help companies of all sizes migrate their enterprise data seamlessly, securely, and with zero downtime.", "metaKeywords": "clients, customers, case studies, enterprise, success stories", "ctaButtonLink": "/contact", "ctaButtonText": "Contact Sales", "metaDescription": "See how leading organizations use Prism Migration tools to translate, convert, and sync mailbox databases."}	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: source_formats; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.source_formats (id, format_key, name, description, icon, site_id, supports_multiple_accounts, category) FROM stdin;
sf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	microsoft-outlook	brandA	f	Email
apexbyte-sf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	mail	apexbyte	f	Email
apexbyte-sf-mbox	mbox	MBOX File	Standard MBOX mailbox archive file	mail	apexbyte	f	Email
brandD-sf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	mail	brandD	f	Email
brandD-sf-mbox	mbox	MBOX File	Standard MBOX mailbox archive file	mail	brandD	f	Email
brandE-sf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	mail	brandE	f	Email
brandE-sf-mbox	mbox	MBOX File	Standard MBOX mailbox archive file	mail	brandE	f	Email
migrationuncle-sf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	mail	migrationuncle	f	Email
migrationuncle-sf-mbox	mbox	MBOX File	Standard MBOX mailbox archive file	mail	migrationuncle	f	Email
sf-ost	ost	Outlook OST File	Microsoft Outlook Offline Storage Table	microsoft-outlook	brandA	f	Email
sf-vcf	vcf	vCard File	vCard electronic business card format	contact	brandA	f	Contacts
sf-ics	ics	iCalendar File	iCalendar calendar and scheduling format	calendar	brandA	f	Calendar
sf-msg	msg	Outlook MSG File	Outlook individual message format	microsoft-outlook	brandA	f	Email
sf-olm-bA	olm	Mac Outlook OLM File	Outlook for Mac Archive (.olm)	microsoft-outlook	brandA	f	Email
sf-gmail	gmail	Gmail / Google Mail	Google Mail IMAP account	gmail	brandA	f	Email
sf-gws-bA	google_workspace	Google Workspace	Google Workspace / G Suite accounts	google-workspace	brandA	t	Cloud Platform
sf-office365	office365	Office 365 / Outlook.com	Microsoft 365 Cloud account	microsoft-365	brandA	f	Email
sf-yahoo-bA	yahoo	Yahoo Mail	Yahoo Mail accounts via IMAP/API	yahoo	brandA	t	Email
sf-mbox	mbox	MBOX File	Standard MBOX mailbox archive file	thunderbird	brandA	f	Email
sf-nsf-bA	nsf	Lotus Notes NSF File	HCL/IBM Lotus Notes Database (.nsf)	ibm-lotus-notes	brandA	f	Email
sf-zimbra-bA	zimbra	Zimbra TGZ File	Zimbra Desktop/Server Archive (.tgz)	zimbra	brandA	f	Email
sf-eml	eml	EML File	Individual email message file format	email-file	brandA	f	Email
sf-emlx-bA	emlx	EMLX File	Apple Mail Message format (.emlx)	email-file	brandA	f	Email
sf-dbx-bA	dbx	Outlook Express DBX File	Outlook Express Folder (.dbx)	email-file	brandA	f	Email
sf-tgz	tgz	Zimbra TGZ File	Zimbra mailbox export archive format	email-file	brandA	f	Email
sf-maildir	maildir	Maildir File	Standard Maildir directory-based mail format	email-file	brandA	f	Email
UUID-nzm3y3gpsq	imap	IMAP	Auto-migrated format imap	file	brandA	t	Email
05ef8348-5c66-4732-afee-9b8b0ad9cd33	site-migration	Outlook site migration		drive	brandA	t	Cloud Storage
sf-edb-bA	edb	Exchange EDB File	Microsoft Exchange Server Database (.edb)	server	brandA	t	Database
sf-mobi	mobi	MOBI E-book	Mobipocket e-book format	document	brandA	f	File Format
sf-epub	epub	EPUB E-book	Electronic Publication open e-book format	document	brandA	f	File Format
sf-exchange-bA	exchange	Exchange Server	On-Premises Microsoft Exchange Server	microsoft-365	brandA	t	Database
sf-xlsx	xlsx	Excel Worksheet	Microsoft Excel spreadsheet format	microsoft-excel	brandA	f	File Format
sf-csv	csv	CSV File	Comma Separated Values text table format	microsoft-excel	brandA	f	File Format
sf-docx	docx	Word Document	Microsoft Word document format	microsoft-word	brandA	f	File Format
sf-yaml	yaml	YAML File	YAML Ain't Markup Language serialization format	code-file	brandA	f	File Format
sf-xml	xml	XML File	eXtensible Markup Language document format	code-file	brandA	f	File Format
sf-toml	toml	TOML File	Tom's Obvious Minimal Language config format	code-file	brandA	f	File Format
sf-properties	properties	Properties File	Java configuration properties format	code-file	brandA	f	File Format
sf-md	markdown	Markdown File	Markdown text file format	code-file	brandA	f	File Format
sf-jsonl	jsonl	JSON Lines File	Line-delimited JSON format	code-file	brandA	f	File Format
sf-json	json	JSON File	JavaScript Object Notation data format	code-file	brandA	f	File Format
sf-ini	ini	INI File	Initialization configuration file format	code-file	brandA	f	File Format
\.


--
-- Data for Name: supported_clients; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.supported_clients (id, client_key, name, description, icon, site_id) FROM stdin;
apexbyte-sc-outlook	outlook	Microsoft Outlook	Desktop client for Windows & Mac	mail	apexbyte
brandD-sc-outlook	outlook	Microsoft Outlook	Desktop client for Windows & Mac	mail	brandD
brandE-sc-outlook	outlook	Microsoft Outlook	Desktop client for Windows & Mac	mail	brandE
migrationuncle-sc-outlook	outlook	Microsoft Outlook	Desktop client for Windows & Mac	mail	migrationuncle
sc-outlook	outlook	Microsoft Outlook	Desktop client for Windows & Mac	mail	brandA
sc-thunderbird	thunderbird	Mozilla Thunderbird	Open-source email desktop client	mail	brandA
sc-applemail	applemail	Apple Mail	Built-in macOS/iOS email client	mail	brandA
sc-gmail	gmail	Google Webmail	Gmail web interface on browsers	mail	brandA
sc-wlm-bA	windows_live_mail	Windows Live Mail	Legacy Windows email client	mail	brandA
sc-emclient-bA	emclient	eM Client	Modern email client for Windows/Mac	mail	brandA
sc-mailbird-bA	mailbird	Mailbird	Desktop email client for Windows	mail	brandA
sc-postbox-bA	postbox	Postbox	Desktop email client	mail	brandA
sc-thebat-bA	thebat	The Bat!	Secure desktop email client	mail	brandA
sc-entourage-bA	entourage	Microsoft Entourage	Legacy Mac email client	mail	brandA
sc-eudora-bA	eudora	Eudora	Classic email client	mail	brandA
sc-lotus-bA	lotus_notes	Lotus Notes / HCL Notes	Enterprise email and collaboration	mail	brandA
sc-zimbra-bA	zimbra	Zimbra Desktop	Open-source email client	mail	brandA
sc-lotusnotes	lotusnotes	Lotus Notes / Domino	IBM Lotus Notes collaboration platform	mail	brandA
sc-outlookexpress	outlookexpress	Outlook Express	Classic Windows Mail / Outlook Express	mail	brandA
sc-exchange	exchange	Microsoft Exchange Server	Exchange on-premise or cloud database	mail	brandA
sc-onedrive	onedrive	Microsoft OneDrive	OneDrive Cloud Storage	cloud	brandA
sc-googledrive	googledrive	Google Drive	Google Workspace Cloud Storage	cloud	brandA
sc-yahoo	yahoo	Yahoo Mail	Yahoo Mail accounts via IMAP/API	cloud	brandA
sc-outlook-com	outlook_com	Outlook.com	Outlook.com Personal Cloud accounts	cloud	brandA
sc-godaddy	godaddy	GoDaddy Workspace Mail	GoDaddy Workspace email platform	mail	brandA
sc-zoho	zoho	Zoho Mail	Zoho Mail enterprise server	mail	brandA
sc-workmail	workmail	Amazon WorkMail	AWS Enterprise email and calendar	mail	brandA
sc-yandex	yandex	Yandex Mail	Yandex Mail cloud platform	cloud	brandA
sc-dropbox	dropbox	Dropbox	Dropbox Cloud Storage	cloud	brandA
sc-sharepoint	sharepoint	Microsoft SharePoint	Microsoft SharePoint portal	cloud	brandA
\.


--
-- Data for Name: target_formats; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.target_formats (id, format_key, name, description, icon, site_id, supports_multiple_accounts, category) FROM stdin;
tf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	microsoft-outlook	brandA	f	Email
UUID-qq7zoryd26	msg	MSG	Auto-migrated format msg	microsoft-outlook	brandA	f	Email
tf-olm	olm	Outlook Mac OLM File	Microsoft Outlook for Mac database archive	microsoft-outlook	brandA	f	Email
tf-gmail	gmail	Gmail / Google Mail	Google Mail IMAP account	gmail	brandA	f	Email
tf-gws-bA	google_workspace	Google Workspace	Direct import into Google Workspace	google-workspace	brandA	t	Cloud Platform
tf-office365	office365	Office 365 / Outlook.com	Microsoft 365 Cloud account	microsoft-365	brandA	f	Email
tf-exchange-bA	exchange	Exchange Server	Import into Exchange Server	microsoft-365	brandA	t	Email
tf-mbox	mbox	MBOX File	Standard MBOX mailbox archive file	thunderbird	brandA	f	Email
tf-nsf	nsf	Lotus Notes NSF File	IBM Lotus Notes database format	ibm-lotus-notes	brandA	f	Email
tf-eml	eml	EML File	Individual email message file format	email-file	brandA	f	Email
tf-tgz	tgz	Zimbra TGZ File	Zimbra mailbox export archive format	email-file	brandA	f	Email
tf-maildir	maildir	Maildir File	Standard Maildir directory-based mail format	email-file	brandA	f	Email
tf-emlx	emlx	Apple Mail EMLX File	Apple Mail individual message format	email-file	brandA	f	Email
tf-dbx	dbx	Outlook Express DBX File	Microsoft Outlook Express database format	email-file	brandA	f	Email
apexbyte-tf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	mail	apexbyte	f	Email
brandD-tf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	mail	brandD	f	Email
brandE-tf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	mail	brandE	f	Email
migrationuncle-tf-pst	pst	Outlook PST File	Microsoft Outlook Personal Storage Table	mail	migrationuncle	f	Email
tf-edb	edb	Exchange Database EDB File	Microsoft Exchange Server mailbox database	mail	brandA	f	Email
tf-imap-bA	imap	IMAP Server	Import via IMAP protocol	server	brandA	t	Cloud Platform
tf-vcf-bA	vcf	vCard / VCF	Export contacts as vCard	contact	brandA	f	Contacts
tf-ics-bA	ics	ICS File	Export calendar events	calendar	brandA	f	Calendar
0057b1a9-6071-4fff-80bd-500544cf8d5f	site-migration	Outlook site migration		drive	brandA	t	Cloud Storage
apexbyte-tf-pdf	pdf	PDF Document	Portable Document Format for printing/archiving	file	apexbyte	f	File Format
brandD-tf-pdf	pdf	PDF Document	Portable Document Format for printing/archiving	file	brandD	f	File Format
brandE-tf-pdf	pdf	PDF Document	Portable Document Format for printing/archiving	file	brandE	f	File Format
migrationuncle-tf-pdf	pdf	PDF Document	Portable Document Format for printing/archiving	file	migrationuncle	f	File Format
tf-html	html	HTML File	HyperText Markup Language files for web viewing	file	brandA	f	File Format
tf-rtf-bA	rtf	RTF File	Rich Text Format	file	brandA	f	File Format
tf-mobi	mobi	MOBI E-book	Mobipocket e-book format	document	brandA	f	File Format
tf-epub	epub	EPUB E-book	Electronic Publication open e-book format	document	brandA	f	File Format
tf-txt	txt	Plain Text Document	Plain text message extraction	file	brandA	f	File Format
tf-mht	mht	MHTML Web Archive	Single file HTML web archive	file	brandA	f	File Format
tf-xps	xps	XPS Document	XML Paper Specification	file	brandA	f	File Format
tf-pdf	pdf	PDF Document	Portable Document Format for printing/archiving	adobe-pdf	brandA	f	File Format
tf-csv-bA	csv	CSV File	Comma Separated Values for Contacts/Tables	microsoft-excel	brandA	f	File Format
tf-xlsx	xlsx	Excel Worksheet	Microsoft Excel spreadsheet format	microsoft-excel	brandA	f	File Format
tf-docx	docx	Word Document	Microsoft Word document format	microsoft-word	brandA	f	File Format
tf-yaml	yaml	YAML File	YAML Ain't Markup Language serialization format	code-file	brandA	f	File Format
tf-xml	xml	XML File	eXtensible Markup Language document format	code-file	brandA	f	File Format
tf-toml	toml	TOML File	Tom's Obvious Minimal Language config format	code-file	brandA	f	File Format
tf-properties	properties	Properties File	Java configuration properties format	code-file	brandA	f	File Format
tf-md	markdown	Markdown File	Markdown text file format	code-file	brandA	f	File Format
tf-jsonl	jsonl	JSON Lines File	Line-delimited JSON format	code-file	brandA	f	File Format
tf-json	json	JSON File	JavaScript Object Notation data format	code-file	brandA	f	File Format
tf-ini	ini	INI File	Initialization configuration file format	code-file	brandA	f	File Format
tf-tiff	tiff	TIFF Image	Tagged Image File Format	image-file	brandA	f	Image
tf-bmp	bmp	Bitmap Image	BMP Image format	image-file	brandA	f	Image
tf-gif	gif	GIF Image	Graphics Interchange Format	image-file	brandA	f	Image
tf-jpeg	jpeg	JPEG Image	Joint Photographic Experts Group	image-file	brandA	f	Image
tf-png	png	PNG Image	Portable Network Graphics	image-file	brandA	f	Image
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.testimonials (id, site_id, author_name, author_title, company, content, rating, avatar_url, is_featured, created_at, updated_at, product_ids) FROM stdin;
\.


--
-- Data for Name: trial_downloads; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.trial_downloads (id, email, product_slug, downloaded_at, site_id, product_id) FROM stdin;
\.


--
-- Data for Name: url_redirects; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.url_redirects (id, source_path, target_path, redirect_type, created_at, site_id) FROM stdin;
\.


--
-- Name: inquiries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.inquiries_id_seq', 1, false);


--
-- Name: license_activations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.license_activations_id_seq', 57, true);


--
-- Name: licenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.licenses_id_seq', 98, true);


--
-- Name: trial_downloads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.trial_downloads_id_seq', 1, false);


--
-- Name: url_redirects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.url_redirects_id_seq', 1, false);


--
-- Name: activations activations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.activations
    ADD CONSTRAINT activations_pkey PRIMARY KEY (id);


--
-- Name: admin_users admin_users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.admin_users
    ADD CONSTRAINT admin_users_pkey PRIMARY KEY (username);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_slug_key UNIQUE (slug);


--
-- Name: brand_configs brand_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.brand_configs
    ADD CONSTRAINT brand_configs_pkey PRIMARY KEY (id);


--
-- Name: career_positions career_positions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.career_positions
    ADD CONSTRAINT career_positions_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_key UNIQUE (slug);


--
-- Name: client_logos client_logos_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.client_logos
    ADD CONSTRAINT client_logos_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: faqs faqs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.faqs
    ADD CONSTRAINT faqs_pkey PRIMARY KEY (id);


--
-- Name: format_compatibility format_compatibility_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.format_compatibility
    ADD CONSTRAINT format_compatibility_pkey PRIMARY KEY (id);


--
-- Name: help_articles help_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.help_articles
    ADD CONSTRAINT help_articles_pkey PRIMARY KEY (id);


--
-- Name: help_articles help_articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.help_articles
    ADD CONSTRAINT help_articles_slug_key UNIQUE (slug);


--
-- Name: inquiries inquiries_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.inquiries
    ADD CONSTRAINT inquiries_pkey PRIMARY KEY (id);


--
-- Name: key_features key_features_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.key_features
    ADD CONSTRAINT key_features_pkey PRIMARY KEY (id);


--
-- Name: legacy_license_activations legacy_license_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.legacy_license_activations
    ADD CONSTRAINT legacy_license_activations_pkey PRIMARY KEY (id);


--
-- Name: license_activations license_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.license_activations
    ADD CONSTRAINT license_activations_pkey PRIMARY KEY (id);


--
-- Name: license_keys license_keys_activation_key_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.license_keys
    ADD CONSTRAINT license_keys_activation_key_key UNIQUE (activation_key);


--
-- Name: license_keys license_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.license_keys
    ADD CONSTRAINT license_keys_pkey PRIMARY KEY (id);


--
-- Name: licenses licenses_license_key_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_license_key_key UNIQUE (license_key);


--
-- Name: licenses licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.licenses
    ADD CONSTRAINT licenses_pkey PRIMARY KEY (id);


--
-- Name: orders orders_order_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_id_key UNIQUE (order_id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_slug_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_slug_key UNIQUE (slug);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_site_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_site_id_key UNIQUE (site_id);


--
-- Name: source_formats source_formats_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.source_formats
    ADD CONSTRAINT source_formats_pkey PRIMARY KEY (id);


--
-- Name: supported_clients supported_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.supported_clients
    ADD CONSTRAINT supported_clients_pkey PRIMARY KEY (id);


--
-- Name: target_formats target_formats_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.target_formats
    ADD CONSTRAINT target_formats_pkey PRIMARY KEY (id);


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- Name: trial_downloads trial_downloads_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.trial_downloads
    ADD CONSTRAINT trial_downloads_pkey PRIMARY KEY (id);


--
-- Name: license_activations ukcol42u3wtspgxju8yovsvejak; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.license_activations
    ADD CONSTRAINT ukcol42u3wtspgxju8yovsvejak UNIQUE (license_id, machine_id);


--
-- Name: supported_clients uq_client_key_site; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.supported_clients
    ADD CONSTRAINT uq_client_key_site UNIQUE (client_key, site_id);


--
-- Name: coupons uq_coupon_code_site; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT uq_coupon_code_site UNIQUE (code, site_id);


--
-- Name: key_features uq_feature_key_site; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.key_features
    ADD CONSTRAINT uq_feature_key_site UNIQUE (feature_key, site_id);


--
-- Name: license_activations uq_license_activations_license_machine; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.license_activations
    ADD CONSTRAINT uq_license_activations_license_machine UNIQUE (license_id, machine_id);


--
-- Name: source_formats uq_source_format_key_site; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.source_formats
    ADD CONSTRAINT uq_source_format_key_site UNIQUE (format_key, site_id);


--
-- Name: target_formats uq_target_format_key_site; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.target_formats
    ADD CONSTRAINT uq_target_format_key_site UNIQUE (format_key, site_id);


--
-- Name: url_redirects url_redirects_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.url_redirects
    ADD CONSTRAINT url_redirects_pkey PRIMARY KEY (id);


--
-- Name: idx_admin_users_brand_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_admin_users_brand_id ON public.admin_users USING btree (brand_id);


--
-- Name: idx_admin_users_role; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_admin_users_role ON public.admin_users USING btree (role);


--
-- Name: idx_blog_posts_seo_lookup; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_blog_posts_seo_lookup ON public.blog_posts USING btree (site_id, slug);


--
-- Name: idx_categories_seo_lookup; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_categories_seo_lookup ON public.categories USING btree (site_id, slug);


--
-- Name: idx_client_logos_site_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_client_logos_site_id ON public.client_logos USING btree (site_id);


--
-- Name: idx_fc_source_format; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_fc_source_format ON public.format_compatibility USING btree (source_format);


--
-- Name: idx_fc_target_format; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_fc_target_format ON public.format_compatibility USING btree (target_format);


--
-- Name: idx_help_articles_seo_lookup; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_help_articles_seo_lookup ON public.help_articles USING btree (site_id, slug);


--
-- Name: idx_kf_site_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_kf_site_id ON public.key_features USING btree (site_id);


--
-- Name: idx_products_seo_lookup; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_products_seo_lookup ON public.products USING btree (site_id, slug);


--
-- Name: idx_sc_site_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_sc_site_id ON public.supported_clients USING btree (site_id);


--
-- Name: idx_sf_site_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_sf_site_id ON public.source_formats USING btree (site_id);


--
-- Name: idx_testimonials_site_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_testimonials_site_id ON public.testimonials USING btree (site_id);


--
-- Name: idx_tf_site_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_tf_site_id ON public.target_formats USING btree (site_id);


--
-- Name: idx_url_redirects_lookup; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_url_redirects_lookup ON public.url_redirects USING btree (site_id, source_path);


--
-- Name: activations fk_activation_license; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.activations
    ADD CONSTRAINT fk_activation_license FOREIGN KEY (license_id) REFERENCES public.licenses(id) ON DELETE CASCADE;


--
-- Name: legacy_license_activations fk_legacy_activation_license_key; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.legacy_license_activations
    ADD CONSTRAINT fk_legacy_activation_license_key FOREIGN KEY (license_key_id) REFERENCES public.license_keys(id) ON DELETE CASCADE;


--
-- Name: license_activations fk_license_activations_license; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.license_activations
    ADD CONSTRAINT fk_license_activations_license FOREIGN KEY (license_id) REFERENCES public.licenses(id);


--
-- PostgreSQL database dump complete
--

\unrestrict xieJMOIRNRGS9mCTxWQDwXetnuhmu0VCBb3hLz2uHYPYjXJ9G5d2bNzFxqFaIA2

